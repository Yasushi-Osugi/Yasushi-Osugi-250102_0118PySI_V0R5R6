#gui_psi_graph250114.py



# main.py
import tkinter as tk
from gui.app import PSIPlannerApp

def main():
    root = tk.Tk()
    app = PSIPlannerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()


# gui/app.py
import tkinter as tk
from gui.psi_graph import PSIPlot

class PSIPlannerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Global Weekly PSI Planner")
        self.setup_ui()

    def setup_ui(self):
        # Create main frames
        self.left_frame = tk.Frame(self.root, width=500)
        self.left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.right_frame = tk.Frame(self.root, width=500)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Initialize PSI Plot
        self.psi_plot = PSIPlot(self.right_frame)

        # Control buttons for demonstration
        btn_draw = tk.Button(self.left_frame, text="Draw PSI Graph", command=self.draw_sample_psi)
        btn_draw.pack(pady=10)

        btn_clear = tk.Button(self.left_frame, text="Clear PSI Graph", command=self.clear_psi_graph)
        btn_clear.pack(pady=10)

    def draw_sample_psi(self):
        weeks = list(range(1, 11))
        supply = [week * 10 for week in weeks]
        demand = [week * 8 for week in weeks]
        self.psi_plot.draw_psi(weeks, supply, demand)

    def clear_psi_graph(self):
        self.psi_plot.clear()



# gui/psi_graph.py
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class PSIPlot:
    def __init__(self, parent_frame):
        """Initialize the PSI graph plot within a given Tkinter frame."""
        self.fig, self.ax = plt.subplots()
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def draw_psi(self, weeks, supply, demand, mode="outbound"):
        """
        Draw the PSI graph with given data.

        Parameters:
            weeks (list): List of week numbers.
            supply (list): List of supply values corresponding to weeks.
            demand (list): List of demand values corresponding to weeks.
            mode (str): Mode for the PSI graph title (default: "outbound").
        """
        try:
            self.ax.clear()
            self.ax.set_title(f"PSI Graph - {mode.capitalize()}")
            self.ax.set_xlabel("Weeks")
            self.ax.set_ylabel("Values")
            self.ax.plot(weeks, supply, label="Supply")
            self.ax.plot(weeks, demand, label="Demand")
            self.ax.legend()
            self.canvas.draw()
        except Exception as e:
            print(f"Failed to draw PSI graph: {e}")

    def clear(self):
        """Clear the current PSI graph."""
        self.ax.clear()
        self.canvas.draw()


