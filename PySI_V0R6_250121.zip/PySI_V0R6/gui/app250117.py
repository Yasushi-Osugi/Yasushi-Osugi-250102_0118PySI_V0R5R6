#250114gui_app.py

# gui/app.py
import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import networkx as nx


from utils.config import Config


# gui/app.py
class PSIPlannerApp:
    def __init__(self, root, config):
    #def __init__(self, root):

        self.root = root
        self.config = config
        self.root.title(self.config.APP_NAME)
        
        self.tree_structure = None
        self.setup_ui()


    def setup_ui(self):
        # Create menu bar
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Load Tree Structure", command=self.load_tree_structure)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        optimize_menu = tk.Menu(menubar, tearoff=0)
        optimize_menu.add_command(label="View Optimization Graph", command=self.view_nx_matlib4opt)
        menubar.add_cascade(label="Optimize", menu=optimize_menu)

        self.root.config(menu=menubar)

        # Split frames for network graph and PSI graph
        self.left_frame = tk.Frame(self.root, width=500)
        self.left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.right_frame = tk.Frame(self.root, width=500)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Network Graph Area
        self.fig_network, self.ax_network = plt.subplots()
        self.canvas_network = FigureCanvasTkAgg(self.fig_network, master=self.left_frame)
        self.canvas_network.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # PSI Graph Area
        self.fig_psi, self.ax_psi = plt.subplots()
        self.canvas_psi = FigureCanvasTkAgg(self.fig_psi, master=self.right_frame)
        self.canvas_psi.get_tk_widget().pack(fill=tk.BOTH, expand=True)


    def load_tree_structure(self):
        try:
            file_path = filedialog.askopenfilename(title="Select Tree Structure File")
            if not file_path:
                return
            # Placeholder for loading tree structure
            self.tree_structure = nx.DiGraph()
            self.tree_structure.add_edge("Root", "Child1")
            self.tree_structure.add_edge("Root", "Child2")
            messagebox.showinfo("Success", "Tree structure loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load tree structure: {e}")


    def view_nx_matlib4opt(self):
        try:
            if self.tree_structure is None:
                raise ValueError("Tree structure is not loaded.")

            self.ax_network.clear()
            nx.draw(self.tree_structure, with_labels=True, ax=self.ax_network)
            self.canvas_network.draw()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display optimization graph: {e}")


