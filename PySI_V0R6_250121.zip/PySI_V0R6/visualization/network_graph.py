#visualization/network_graph.py


import networkx as nx
import matplotlib.pyplot as plt

def view_nx_matlib_stop_draw(root_node_outbound, nodes_outbound, root_node_inbound, nodes_inbound):
    G = nx.DiGraph()
    Gdm_structure = nx.DiGraph()
    Gsp = nx.DiGraph()

    print("view_nx_matlib before show_network_E2E_matplotlib")

    pos_E2E, G, Gdm_structure, Gsp = show_network_E2E_matplotlib(
        root_node_outbound, nodes_outbound,
        root_node_inbound, nodes_inbound,
        G, Gdm_structure, Gsp
    )

    print("view_nx_matlib after show_network_E2E_matplotlib")

    return pos_E2E, G, Gdm_structure, Gsp

def show_network_E2E_matplotlib(root_outbound, nodes_outbound, root_inbound, nodes_inbound, G, Gdm_structure, Gsp):
    # ネットワークの作成とレイアウト処理の実装をここに記述
    # 例:
    pos = nx.spring_layout(G)  # 仮のレイアウト
    return pos, G, Gdm_structure, Gsp

def draw_network(G, Gdm_structure, Gsp, pos):
    plt.figure(figsize=(12, 8))
    nx.draw_networkx(G, pos)
    plt.show()


