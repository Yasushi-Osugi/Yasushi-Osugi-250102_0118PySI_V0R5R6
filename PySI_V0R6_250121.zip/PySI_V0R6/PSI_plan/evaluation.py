#PSI_plan.evaluation.py

def eval_supply_chain_cost(node, context):
    """
    再帰的にサプライチェーン全体のコストを評価。
    
    Parameters:
        node (Node): 現在評価中のノード。
        context (object): コスト合計値を保持するオブジェクト（例: GUIクラスインスタンス）。
    """
    # 各ノードのロット数をカウント
    node.set_lot_counts()

    # コスト評価を実行
    total_revenue, total_profit = node.EvalPlanSIP_cost()

    # 評価結果をコンテキストに加算
    context.total_revenue += total_revenue
    context.total_profit += total_profit

    # 子ノードに対して再帰的に評価
    for child in node.children:
        eval_supply_chain_cost(child, context)


