#250118make_edge_weight_capacity.py

# *************************************************


def make_edge_weight_capacity(node, child):
    # Weight
    # - `weight` represents the movement cost between two nodes defined by the edge.
    #   Corresponds to the total amount of logistics costs, tariffs, storage costs, etc.
    # - For example, if the logistics cost is high, the `weight` of the corresponding edge increases.
    #   Applying the shortest path algorithm (Dijkstra's algorithm) will select the appropriate route.
    #
    # self.demandにセット?
    #

    # *********************
    # add_edge_parameter_set_weight_capacity()
    # Preprocessing before add_edge()
    # *********************
    # capacity
    # - `capacity` represents the constraint on the amount of movement per period between two nodes defined by the edge.
    # - In the case of a supply chain, consider the following application constraints to set the minimum value as the bottleneck condition:
    #     - Upper limit of logistics capacity between nodes within the period
    #     - Upper limit of customs processing capacity within the period
    #     - Upper limit of storage warehouse capacity
    #     - Upper limit of shipping and dispatching capacity within the period


    # *****************************************************
    # Evaluate for calculating inventory storage costs
    # For child node child.
    # *****************************************************
    stock_cost = 0

    #@ To be confirmed
    #@241231 Evaluate with the new cost_table here
    child.EvalPlanSIP_cost()

    stock_cost = child.eval_WH_cost = sum(child.WH_cost[1:])

    customs_tariff = 0

    #@241231 Tariff rate x Purchase price
    customs_tariff = child.customs_tariff_rate * child.cs_direct_materials_costs

    print("child.name", child.name)
    print("child.customs_tariff_rate", child.customs_tariff_rate)
    print("child.cs_direct_materials_costs", child.cs_direct_materials_costs)
    print("customs_tariff", customs_tariff)

    print("self.cs_price_sales_shipped", node.cs_price_sales_shipped)
    print("self.cs_cost_total", node.cs_cost_total)
    print("self.cs_profit", node.cs_profit)


    # Absorption method of tariff costs 1
    # 1. Maintain profit and add to cost and price.
    # 2. Maintain price, add to cost, and reduce profit.

    # self.cs_price_sales_shipped # revenue
    # self.cs_cost_total          # cost
    # self.cs_profit              # profit


    #@ OLD STOP
    # Tariff rate x Price
    #customs_tariff = child.customs_tariff_rate * child.REVENUE_RATIO



    weight4nx = 0


    # Logistics cost
    # + TAX customs_tariff
    # + Inventory storage cost
    # weight4nx = child.Distriburion_Cost + customs_tariff + stock_cost


    #@241231 Hypothesis: Reduce profit by 50% of the tariff increase
    cost_portion = 0.5  # price_portion = 0.5 is following

    #@ RUN 
    weight4nx = child.cs_cost_total + (customs_tariff * cost_portion)



    #@ STOP
    #weight4nx = child.cs_profit_accume - (customs_tariff * cost_portion)
    #weight4nx =100*2 - child.cs_profit_accume + (customs_tariff *cost_portion)

    #print("child.cs_profit_accume", child.cs_profit_accume)

    print("child.cs_cost_total", child.cs_cost_total)

    print("customs_tariff", customs_tariff)
    print("cost_portion", cost_portion)
    print("weight4nx", weight4nx)



    if weight4nx < 0:
        weight4nx = 0


    # Shipping cost is included in PO_cost
    ## Shipping cost
    # + xxxx

    #print("child.Distriburion_Cost", child.Distriburion_Cost)
    #print("+ TAX customs_tariff", customs_tariff)
    #print("+ stock_cost", stock_cost)
    #print("weight4nx", weight4nx)

    # ******************************
    # capacity4nx = 3 * average demand lots # 3 times the average weekly demand
    # ******************************
    capacity4nx = 0

    # ******************************
    # average demand lots
    # ******************************
    demand_lots = 0
    ave_demand_lots = 0

    for w in range(53 * node.plan_range):
        demand_lots += len(node.psi4demand[w][0])

    ave_demand_lots = demand_lots / (53 * node.plan_range)

    #@241231 Hypothesis: Assume a price elasticity of demand of 1 due to a 50% increase in tariff on the demand curve.
    # on the demand curve,
    # assume a price elasticity of demand of 1 due to price increase.

    # self.cs_price_sales_shipped # revenue

    # demand_on_curve Demand on the demand curve
    # customs_tariff*0.5 50% of the tariff
    # self.cs_price_sales_shipped Sales

    # Demand change due to price elasticity
    # customs_tariff*0.5 / self.cs_price_sales_shipped Price increase rate
    # self.price_elasticity
    # 0.0: demand "stay" like a medicine
    # 1.0: demand_decrease = price_increse * 1
    # 2.0: demand_decrease = price_increse * 2

    #@241231 MEMO demand_curve
    # Normally, demand is reduced at the terminal market leaf_node when prices rise,
    # but here, the same effect is achieved by reducing demand with the capacity of the intermediate node at customs clearance.

    # As it is not the final price, the rate of price change due to tariffs differs?
    # customs_tariff: Temporarily store the cost of the tariff increase in self.customs_tariff
    # Demand_on_curve at the final price of the leaf_node = Price increase rate * node.price_elasticity


    # Add (customs_tariff * 0.5) to node.tariff_on_price of the lead_node

    def add_tariff_on_leaf(node, customs_tariff):

        price_portion = 0.5 # cost_portion = 0.5 is previously defined

        if node.children == []:  # leaf_node
            node.tariff_on_price += customs_tariff * price_portion # 0.5
        else:
            for child in node.children:
                add_tariff_on_leaf(child, customs_tariff)

    add_tariff_on_leaf(node, customs_tariff)

    #@ STOP
    #demand_on_curve = 3 * ave_demand_lots * (1-(customs_tariff*0.5 / node.cs_price_sales_shipped) * node.price_elasticity )
    #
    #capacity4nx = demand_on_curve       # 


    #@ STOP RUN
    capacity4nx = 3 * ave_demand_lots  # N * ave weekly demand

    print("weight4nx", weight4nx)
    print("capacity4nx", capacity4nx)

    return weight4nx, capacity4nx  # Return as float


# *************************************************


import networkx as nx

def make_edge_weight_capacity(node, child):
    # Calculate stock cost and customs tariff
    child.EvalPlanSIP_cost()
    stock_cost = sum(child.WH_cost[1:])
    customs_tariff = child.customs_tariff_rate * child.cs_direct_materials_costs

    # Determine weight (logistics cost + tax + storage cost)
    cost_portion = 0.5
    weight4nx = max(0, child.cs_cost_total + (customs_tariff * cost_portion))

    # Calculate capacity (3 times the average weekly demand)
    demand_lots = sum(len(node.psi4demand[w][0]) for w in range(53 * node.plan_range))
    ave_demand_lots = demand_lots / (53 * node.plan_range)
    capacity4nx = 3 * ave_demand_lots

    # Add tariff to leaf nodes
    def add_tariff_on_leaf(node, customs_tariff):
        if not node.children:
            node.tariff_on_price += customs_tariff * cost_portion
        else:
            for child in node.children:
                add_tariff_on_leaf(child, customs_tariff)

    add_tariff_on_leaf(node, customs_tariff)

    # Logging for debugging (optional)
    print(f"child.name: {child.name}")
    print(f"weight4nx: {weight4nx}, capacity4nx: {capacity4nx}")

    return weight4nx, capacity4nx

# Example usage with networkx
G = nx.DiGraph()
weight, capacity = make_edge_weight_capacity(node, child)
G.add_edge(node.name, child.name, weight=weight, capacity=capacity)

# *************************************************

