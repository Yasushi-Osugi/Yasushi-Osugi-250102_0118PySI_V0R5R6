

# PSI_plan/planning_operation.py

# ****************************
# PSI planning operation on tree
# ****************************

def set_S2psi(node, pSi):

    # S_lots_listが辞書で、node.psiにセットする

    # print("len(node.psi4demand) = ", len(node.psi4demand) )
    # print("len(pSi) = ", len(pSi) )

    for w in range(len(pSi)):  # Sのリスト

        node.psi4demand[w][0].extend(pSi[w])



def calcS2P(node): # backward planning

    # **************************
    # Safety Stock as LT shift
    # **************************
    # leadtimeとsafety_stock_weekは、ここでは同じ

    # 同一node内なので、ssのみで良い
    shift_week = int(round(node.SS_days / 7))

    ## stop 同一node内でのLT shiftは無し
    ## SS is rounded_int_num
    # shift_week = node.leadtime +  int(round(node.SS_days / 7))

    # **************************
    # long vacation weeks
    # **************************
    lv_week = node.long_vacation_weeks

    # 同じnode内でのS to P の計算処理 # backward planning
    node.psi4demand = shiftS2P_LV(node.psi4demand, shift_week, lv_week)

    pass




def get_set_childrenP2S2psi(node, plan_range):

    for child in node.children:

        for w in range(node.leadtime, 53 * plan_range):

            # ******************
            # logistics LT switch
            # ******************
            # 物流をnodeとして定義する場合の表現 STOP
            # 子node childのP [3]のweek positionを親node nodeのS [0]にset
            # node.psi4demand[w][0].extend(child.psi4demand[w][3])

            # 物流をLT_shiftで定義する場合の表現 GO
            # childのPのweek positionをLT_shiftして、親nodeのS [0]にset
            ws = w - node.leadtime
            node.psi4demand[ws][0].extend(child.psi4demand[w][3])






