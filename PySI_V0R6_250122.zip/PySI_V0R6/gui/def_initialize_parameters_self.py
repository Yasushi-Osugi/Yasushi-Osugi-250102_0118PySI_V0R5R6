




    def initialize_parameters(self):
        # Global Market Potentialの計算と設定
        market_potential = getattr(self, 'market_potential', self.market_potential)  # 初期設定を含む

        self.gmp_entry.delete(0, tk.END)
        self.gmp_entry.insert(0, "{:,}".format(market_potential))  # 3桁毎にカンマ区切りで表示

        # Target Shareの初期値設定（すでにsetup_uiで設定済み）

        # Total Supply Planの計算と設定
        target_share = float(self.ts_entry.get().replace('%', ''))/100  # 文字列を浮動小数点数に変換して%を除去

        total_supply_plan = round(market_potential * target_share)
        self.tsp_entry.delete(0, tk.END)
        self.tsp_entry.insert(0, "{:,}".format(total_supply_plan))  # 3桁毎にカンマ区切りで表示

        #self.global_market_potential  = global_market_potential

        self.market_potential         = market_potential
        self.target_share             = target_share           
        self.total_supply_plan        = total_supply_plan
        print(f"初期化時 - market_potential: {self.market_potential}, target_share: {self.target_share}")  # ログ追加




