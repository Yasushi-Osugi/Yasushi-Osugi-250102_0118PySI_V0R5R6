#250114gui_app.py

# gui/app.py

# ********************************
# library import
# ********************************
import os
import shutil
import threading

import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import font as tkfont, Tk, Menu, ttk

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


import networkx as nx


import datetime as dt
from datetime import datetime as dt_datetime, timedelta

import math

# ********************************
# library import
# ********************************
#
#import mpld3
#from mpld3 import plugins
#
#from collections import defaultdict
#
#
#import numpy as np
#
#from dateutil.relativedelta import relativedelta
#
#import calendar
#
#import copy
import pickle



# ********************************
# PySI library import
# ********************************
from utils.config import Config

from utils.file_io import *
#from utils.file_io import load_cost_table
#from utils.file_io import load_monthly_demand

from PSI_plan.demand_generate import convert_monthly_to_weekly

#from PSI_plan.demand_processing import *
from PSI_plan.demand_processing import set_df_Slots2psi4demand

from network.tree import *
#from network.tree import create_tree_set_attribute
#from network.tree import set_node_costs

#from network.tree import calc_all_psi2i4demand, set_lot_counts

#from PSI_plan.planning_operation import calcS2P, set_S2psi, get_set_childrenP2S2psi, calc_all_psi2i4demand, calcPS2I4demand

#@ STOP
#from visualization.network_graph import view_nx_matlib_stop_draw




# ********************************
# Definition start
# ********************************


#def trans_month2week2lot_id_list(file_name, lot_size)
def process_monthly_demand(file_name, lot_size):
    """
    Process monthly demand data and convert to weekly data.

    Parameters:
        file_name (str): Path to the monthly demand file.
        lot_size (int): Lot size for allocation.

    Returns:
        pd.DataFrame: Weekly demand data with ISO weeks and lot IDs.
    """
    monthly_data = load_monthly_demand(file_name)
    if monthly_data.empty:
        print("Error: Failed to load monthly demand data.")
        return None

    return convert_monthly_to_weekly(monthly_data, lot_size)




def read_set_cost(file_path, nodes_outbound):
    """
    Load cost table from file and set node costs.

    Parameters:
        file_path (str): Path to the cost table file.
        nodes_outbound (dict): Dictionary of outbound nodes.

    Returns:
        None
    """
    cost_table = load_cost_table(file_path)
    if cost_table is not None:
        set_node_costs(cost_table, nodes_outbound)




# ****************************
# ������tree node��demand & supply�ɐڑ�����
# ****************************
def set_dict2tree_psi(node, attr_name, node_psi_dict):

    setattr(node, attr_name, node_psi_dict.get(node.name))

    # node.psi4supply = node_psi_dict.get(node.name)

    for child in node.children:

        set_dict2tree_psi(child, attr_name, node_psi_dict)


# node����J��Ȃ���node_psi_dict����������������
def make_psi_space_dict(node, node_psi_dict, plan_range):

    psi_list = [[[] for j in range(4)] for w in range(53 * plan_range)]

    node_psi_dict[node.name] = psi_list  # �V����dict��psi���Z�b�g

    for child in node.children:

        make_psi_space_dict(child, node_psi_dict, plan_range)

    return node_psi_dict




# *******************
# ���Y�������̑O�����@���b�g�E�J�E���g
# *******************
def count_lots_yyyy(psi_list, yyyy_str):

    matrix = psi_list

    # ���ʂ̕�������J�E���g���邽�߂̕ϐ���������
    count_common_string = 0

    # Step 1: �}�g���N�X���̊e�v�f�̕���������[�v�Œ��ׂ�
    for row in matrix:

        for element in row:

            # Step 2: �e�v�f���̕����� "2023" ���܂ނ��ǂ����𔻒�
            if yyyy_str in element:

                # Step 3: �܂ޏꍇ�̓J�E���^�[�𑝂₷
                count_common_string += 1

    return count_common_string


def is_52_or_53_week_year(year):
    # �w�肳�ꂽ�N��12��31�����擾
    last_day_of_year = dt.date(year, 12, 31)

    # 12��31����ISO�T�ԍ����擾 (isocalendar()���\�b�h�̓^�v����[ISO�N, ISO�T�ԍ�, ISO�j��]��Ԃ�)
    _, iso_week, _ = last_day_of_year.isocalendar()

    # ISO�T�ԍ���1�̏ꍇ�͑O�N�̍Ō�̏T�Ȃ̂ŁA52�T�Ɣ���
    if iso_week == 1:
        return 52
    else:
        return iso_week


def find_depth(node):
    if not node.parent:
        return 0
    else:
        return find_depth(node.parent) + 1


def find_all_leaves(node, leaves, depth=0):
    if not node.children:
        leaves.append((node, depth))  # (leaf�m�[�h, �[��) �̃^�v����ǉ�
    else:
        for child in node.children:
            find_all_leaves(child, leaves, depth + 1)


def make_nodes_decouple_all(node):

    #
    #    root_node = build_tree()
    #    set_parent(root_node)

    #    leaves = []
    #    find_all_leaves(root_node, leaves)
    #    pickup_list = leaves[::-1]  # �K�w�̐[�����ɕ��ׂ�

    leaves = []
    leaves_name = []

    nodes_decouple = []

    find_all_leaves(node, leaves)
    # find_all_leaves(root_node, leaves)
    pickup_list = sorted(leaves, key=lambda x: x[1], reverse=True)
    pickup_list = [leaf[0] for leaf in pickup_list]  # �[��������菜��

    # �������邱�ƂŁAleaf node���K�w�̐[�����ɕ��בւ��� pickup_list �������܂��B
    # ��ɐ[�������܂߂ĕ��בւ��A�Ō�ɐ[��������菜���Ƃ�������ɂȂ�܂��B

    # ���������Ƃ��āApickup_list��nodes_decouple��copy
    # pickup_list�͎g���܂킵�ŁApop / insert or append / remove���J��Ԃ�
    for nd in pickup_list:
        nodes_decouple.append(nd.name)

    nodes_decouple_all = []

    while len(pickup_list) > 0:

        # list��copy��v�f�Ƃ��Ēǉ�
        nodes_decouple_all.append(nodes_decouple.copy())

        current_node = pickup_list.pop(0)
        del nodes_decouple[0]  # ��������node.name�̏���

        parent_node = current_node.parent

        if parent_node is None:
            break

        # �e�m�[�h��pick up�ΏۂƂ���pickup_list�ɒǉ�
        if current_node.parent:

            #    pickup_list.append(current_node.parent)
            #    nodes_decouple.append(current_node.parent.name)

            # if parent_node not in pickup_list:  # �d���ǉ���h��

            # �e�m�[�h�̐[�������āA�\�[�g����pickup_list�ɒǉ�
            depth = find_depth(parent_node)
            inserted = False

            for idx, node in enumerate(pickup_list):

                if find_depth(node) <= depth:

                    pickup_list.insert(idx, parent_node)
                    nodes_decouple.insert(idx, parent_node.name)

                    inserted = True
                    break

            if not inserted:
                pickup_list.append(parent_node)
                nodes_decouple.append(parent_node.name)

            # �e�m�[�h���猩���q�m�[�h��pickup_list����폜
            for child in parent_node.children:

                if child in pickup_list:

                    pickup_list.remove(child)
                    nodes_decouple.remove(child.name)

        else:

            print("error: node dupplicated", parent_node.name)

    return nodes_decouple_all






    # +++++++++++++++++++++++++++++++++++++++++++++++
    # Mother Plant demand leveling 
    # +++++++++++++++++++++++++++++++++++++++++++++++
def demand_leveling_on_ship(root_node_outbound, pre_prod_week, year_st, year_end):

    # input: root_node_outbound.psi4demand
    #        pre_prod_week =26 
    #
    # output:root_node_outbound.psi4supply

    plan_range = root_node_outbound.plan_range


    #@241114
    # �����o�����X�̖��́A�ЂƂ�̃l�b�g���[�N�S�̂�optimize�ŉ���

    # ���b�g�P�ʂŋ�����ω������āAweight=���b�g(CPU_profit)���v��simulate
    # �ݔ������̉�����Ԃ�����

    # ����>=���v�Ȃ�I�y���[�V�������
    # ����<���v�Ȃ狟���z���ƃI�y���[�V�������

    # optimise�ŁA���[�g�Ɨʂ�����
    # PSI�ŁAoperation revenue cost profit���Z�� business �]��

    # �ƊENo1/2/3�̋����헪��simulate���āAbusiness�]������


    # node_psi_dict_Ot4Dm�ł́A���[�s���leafnode�̂݃Z�b�g
    #
    # root_node��S psi_list[w][0]�ɁAleveling���ꂽ�m��o��S_confirm_list���Z�b    �g

    # �N�Ԃ̑����v(��lots)��N�T��s�Ő��Y����B
    # �Ⴆ�΁A�R������s��13�T��s���Y�Ƃ��āA�N�ԑ����v���T���ςɂ���B

    # S�o�ׂŕ��������āAconfirmedS-I-P
    # conf_S����conf_P�𐶐����āAconf_P-S-I  PUSH and PULL

    S_list = []
    S_allocated = []

    year_lots_list = []
    year_week_list = []

    leveling_S_in = []

    leveling_S_in = root_node_outbound.psi4demand

    # psi_list����S_list�𐶐�����
    for psi in leveling_S_in:

        S_list.append(psi[0])

    # �J�n�N���擾����
    plan_year_st = year_st  # �J�n�N�̃Z�b�g in main()�v�C��

    for yyyy in range(plan_year_st, plan_year_st + plan_range + 1):

        year_lots = count_lots_yyyy(S_list, str(yyyy))

        year_lots_list.append(year_lots)

    #        # ���ʂ��o��
    #       #print(yyyy, " year carrying lots:", year_lots)
    #
    #    # ���ʂ��o��
    #   #print(" year_lots_list:", year_lots_list)

    # an image of sample data
    #
    # 2023  year carrying lots: 0
    # 2024  year carrying lots: 2919
    # 2025  year carrying lots: 2914
    # 2026  year carrying lots: 2986
    # 2027  year carrying lots: 2942
    # 2028  year carrying lots: 2913
    # 2029  year carrying lots: 0
    #
    # year_lots_list: [0, 2919, 2914, 2986, 2942, 2913, 0]

    year_list = []

    for yyyy in range(plan_year_st, plan_year_st + plan_range + 1):

        year_list.append(yyyy)

        # �e�X�g�p�̔N���w��
        year_to_check = yyyy

        # �w�肳�ꂽ�N��ISO�T�����擾
        week_count = is_52_or_53_week_year(year_to_check)

        year_week_list.append(week_count)

    #        # ���ʂ��o��
    #       #print(year_to_check, " year has week_count:", week_count)
    #
    #    # ���ʂ��o��
    #   #print(" year_week_list:", year_week_list)

    # print("year_list", year_list)

    # an image of sample data
    #
    # 2023  year has week_count: 52
    # 2024  year has week_count: 52
    # 2025  year has week_count: 52
    # 2026  year has week_count: 53
    # 2027  year has week_count: 52
    # 2028  year has week_count: 52
    # 2029  year has week_count: 52
    # year_week_list: [52, 52, 52, 53, 52, 52, 52]


    # *****************************
    # ���Y�������̂��߂̔N�Ԃ̏T���ϐ��Y��(���b�g���P��)
    # *****************************

    # *****************************
    # make_year_average_lots
    # *****************************
    # year_list     = [2023,2024,2025,2026,2027,2028,2029]

    # year_lots_list = [0, 2919, 2914, 2986, 2942, 2913, 0]
    # year_week_list = [52, 52, 52, 53, 52, 52, 52]

    year_average_lots_list = []

    for lots, weeks in zip(year_lots_list, year_week_list):

        average_lots_per_week = math.ceil(lots / weeks)

        year_average_lots_list.append(average_lots_per_week)


    # print("year_average_lots_list", year_average_lots_list)
    #
    # an image of sample data
    #
    # year_average_lots_list [0, 57, 57, 57, 57, 57, 0]

    # �N�Ԃ̑����v(��lots)��N�T��s�Ő��Y����B
    # �Ⴆ�΁A�R������s��13�T��s���Y�Ƃ��āA�N�ԑ����v���T���ςɂ���B

    #
    # ���̓f�[�^�̑O��
    #
    # leveling_S_in[w][0] == S_list�́Aoutbound��demand_plan�ŁA
    # �}�U�[�v�����g�̏o�׃|�W�V������S�ŁA
    # 5�N�� �T�� �ŏI�s��ɂ�����lot_id���X�g��
    # LT offset���ꂽ��Ԃœ����Ă���
    #
    # year_list     = [2023,2024,2025,2026,2027,2028,2029]

    # year_lots_list = [0, 2919, 2914, 2986, 2942, 2913, 0]
    # year_week_list = [52, 52, 52, 53, 52, 52, 52]
    # year_average_lots_list [0, 57, 57, 57, 57, 57, 0]

    # ********************************
    # ��s���Y�̏T��
    # ********************************
    # precedence_production_week =13

    pre_prod_week =26 # 26�T=6�����̐�s���Y���Z�b�g
    # pre_prod_week =13 # 13�T=3�����̐�s���Y���Z�b�g
    # pre_prod_week = 6  # 6�T=1.5�����̐�s���Y���Z�b�g

    # ********************************
    # ��s���Y�̊J�n�T�����߂�
    # ********************************
    # �s�꓊���̑O�N�ɂ����� i= 0  year_list[i]           # 2023
    # �s�꓊���̑O�N��ISO�T�̐� year_week_list[i]         # 52

    # ��s���Y�̊J�n�T�́A�s�꓊���̑O�N��ISO�T�̐� - ��s���Y�T

    pre_prod_start_week = 0

    i = 0

    pre_prod_start_week = year_week_list[i] - pre_prod_week

    # �X�^�[�g�T�̑O�T�܂ŁA[]���X�g�Ŗ��߂Ă���
    for i in range(pre_prod_start_week):
        S_allocated.append([])

    # ********************************
    # �ŏI�s�ꂩ���LT offset���ꂽ�o�חv��lot_id���X�g��
    # Allocate demand to mother plant weekly slots
    # ********************************

    # S_list�̏T��lot_id���X�g���꒼����lot_id���X�g�ɕϊ�����
    # mother plant weekly slots

    # �󃊃X�g�𖳎����āA�꒼����lot_id���X�g�ɕϊ�

    # �󃊃X�g�����O���Ĉ�̃��X�g�Ɍ������鏈��
    S_one_list = [item for sublist in S_list if sublist for item in sublist]

    ## ���ʕ\��
    ##print(S_one_list)

    # to be defined ���N�̒萔�ł�lot_id�̐؂�o��

    # listB�̊e�v�f�Ŏw�肳�ꂽ������listA����v�f��؂�o����
    # �V�������X�glistC���쐬

    listA = S_one_list  # 5�N����lot_id���X�g

    listB = year_lots_list  # ���N���̑����b�g��

    listC = []  # ���N��lot_id���X�g

    start_idx = 0

    for i, num in enumerate(listB):

        end_idx = start_idx + num

        # original sample
        # listC.append(listA[start_idx:end_idx])

        # **********************************
        # "slice" and "allocate" at once
        # **********************************
        sliced_lots = listA[start_idx:end_idx]

        # ���T�̐��Y�g�́Ayear_average_lots_list�̕��ϒl���擾����B
        N = year_average_lots_list[i]

        if N == 0:

            pass

        else:

            # ���̔N�̏T���̏o�ח\�萔�����������B
            S_alloc_a_year = [
                sliced_lots[j : j + N] for j in range(0, len(sliced_lots), N)
            ]

            S_allocated.extend(S_alloc_a_year)
            # S_allocated.append(S_alloc_a_year)

        start_idx = end_idx

    ## ���ʕ\��
    # print("S_allocated", S_allocated)

    # set psi on outbound supply

    # "JPN-OUT"
    #


    # ***********************************************
    #@241113 CHANGE root_node_outbound.psi4supply�����݂���Ƃ����O��
    # ***********************************************
    #
    #node_name = root_node_outbound.name  # Node����node_name����o��
    #
    ## for w, pSi in enumerate( S_allocated ):
    ##
    ##    node_psi_dict_Ot4Sp[node_name][w][0] = pSi
    
    for w in range(53 * plan_range):

        if w <= len(S_allocated) - 1:  # index=0 start

            root_node_outbound.psi4supply[w][0] = S_allocated[w]
            #node_psi_dict_Ot4Sp[node_name][w][0] = S_allocated[w]

        else:

            root_node_outbound.psi4supply[w][0] = []
            #node_psi_dict_Ot4Sp[node_name][w][0] = []

    # +++++++++++++++++++++++++++++++++++++++++++++++






def place_P_in_supply_LT(w, child, lot):  # lot LT_shift on P

    # *******************************************
    # supply_plan��ŁAPfix��Sfix��PIS��LT offset����
    # *******************************************

    # **************************
    # Safety Stock as LT shift
    # **************************

    #@240925 STOP
    ## leadtime��safety_stock_week�́A�����ł͓���
    ## safety_stock_week = child.leadtime
    #LT_SS_week = child.leadtime


    #@240925 �����x�ɂ�LT_SS_week��child.leadtime���ǂ���ɂ���ꍇ��???

    #@240925
    # leadtime��safety_stock_week�͕ʂ���
    LT_SS_week   = child.safety_stock_week
    LT_logi_week = child.leadtime



    # **************************
    # long vacation weeks
    # **************************
    lv_week = child.long_vacation_weeks

    ## P to S �̌v�Z����
    # self.psi4supply = shiftP2S_LV(self.psi4supply, safety_stock_week, lv_week)

    ### S to P �̌v�Z����
    ##self.psi4demand = shiftS2P_LV(self.psi4demand, safety_stock_week, lv_week)

    # my_list = [1, 2, 3, 4, 5]
    # for i in range(2, len(my_list)):
    #    my_list[i] = my_list[i-1] + my_list[i-2]

    # 0:S
    # 1:CO
    # 2:I
    # 3:P


    #@240925 STOP
    ## LT:leadtime SS:safty stock��1��
    ## foreward plan�ŁA�u�econfirmed_S�o��=�qconfirmed_P���ׁv�ƕ\��
    #eta_plan = w + LT_SS_week  # ETA=ETD�Ȃ̂ŁA+LT����Ǝ���ETA�ƂȂ�


    # LT_logi_week�Ŏqnode�܂ł̕���LT���l��
    eta_plan = w + LT_logi_week


    # etd_plan = w + ss # ss:safty stock
    # eta_plan = w - ss # ss:safty stock

    # *********************
    # ���׏T�����Ə�node�̔�ғ��T�̏ꍇ +1���T�̒��ׂƂ���
    # *********************
    # ���׏T�𒲐�
    eta_shift = check_lv_week_fw(lv_week, eta_plan)  # ETA:Eatimate Time Arriv

    # ���X�g�ǉ� extend
    # ���S�݌ɂƃJ�����_������l���������ח\��TP�ɁAw�TS����offset����

    # lot by lot operation
    # confirmed_P made by shifting parent_conf_S

    # ***********************
    # place_lot_supply_plan
    # ***********************

    # �����́A"REPLACE lot"����̂ŁAappend�̑O��child psi��zero clear���Ă���

    #@240925 STOP
    ## �����model�ł́A�A���H����psi node�Ɠ����Ɉ����Ă���(=PO�ł͂Ȃ�)�̂�
    ## �e��confS���u���̂܂܂�W�Łv�q��confP�ɒu�� place_lot����
    #child.psi4supply[w][3].append(lot)

    ## �e��confS���ueta_shift����W�Łv�q��confP�ɒu�� place_lot����
    # �e��confS���uLT=�A��LT + ���HLT + SS��w��shift���āv�qconfS��place_lot

    child.psi4supply[eta_shift][3].append(lot)

    # print("len(child.psi4supply)", len(child.psi4supply) ) # len() of psi list    # print("lot child.name eta_shift ",lot,  child.name, eta_shift )  # LT shift weeks


    # S�́ASS�݌ɕ��̌�ɏo�ׂ���
    ship_position = eta_shift + LT_SS_week

    # �o�׏T�𒲐�
    ship_shift = check_lv_week_fw(lv_week, ship_position) 

    child.psi4supply[ship_shift][0].append(lot)




def find_path_to_leaf_with_parent(node, leaf_node, current_path=[]):

    current_path.append(leaf_node.name)

    if node.name == leaf_node.name:

        return current_path

    else:

        parent = leaf_node.parent

        path = find_path_to_leaf_with_parent(node, parent, current_path.copy())

    return path


#        if path:
#
#            return path


def extract_node_name(stringA):
    """
    Extract the node name from a string by removing the last 9 characters (YYYYWWNNN).

    Parameters:
        stringA (str): Input string (e.g., "LEAF01202601001").

    Returns:
        str: Node name (e.g., "LEAF01").
    """
    if len(stringA) > 9:
        # �Ō��9�������폜���ĕԂ� # deep relation on "def generate_lot_ids()"
        return stringA[:-9]
    else:
        # ������9�����ȉ��̏ꍇ�A�폜�������̂܂ܕԂ��i���S��j
        return stringA


#lot_ID��3���̏ꍇ{i+1:03d}�ɁA 9���������
#lot_ID��4���̏ꍇ{i+1:04d}�ɁA10���������
#10�����́Alot_ID��3���̏ꍇ{i+1:03d}
#
# following "def generate_lot_ids()" is in "demand_generate.py"
#def generate_lot_ids(row):
#    """
#    Generate lot IDs based on the row's data.
#
#    Parameters:
#        row (pd.Series): A row from the DataFrame.
#
#    Returns:
#        list: List of generated lot IDs.
#    """
#    lot_count = row["S_lot"]
#
#    return [f"{row['node_name']}{row['iso_year']}{row['iso_week']}{i+1:03d}" for i in range(lot_count)]
#



def extract_node_name_OLD(stringA):
    # �E���̐������������O����node�����擾

    index = len(stringA) - 1

    while index >= 0 and stringA[index].isdigit():

        index -= 1

    node_name = stringA[: index + 1]

    return node_name





# ******************************************
# confirmedS���o�א�ship2��P��S��shift&set
# ******************************************
def feedback_psi_lists(node, nodes):
#def feedback_psi_lists(node, node_psi_dict, nodes):

    # �L�[�����݂���ꍇ�͑Ή�����lvalue���Ԃ�A���݂��Ȃ��ꍇ��None���Ԃ�B

    if node.children == []:  # �qnode���Ȃ�leaf node�̏ꍇ

        pass

    else:

        # ************************************
        # clearing children P[w][3] and S[w][0]
        # ************************************
        # replace lot���邽�߂ɁA���O�ɁA
        # �o�א�ƂȂ邷�ׂĂ�children nodes��S[w][0]��P[w][3]���N���A

        for child in node.children:

            for w in range(53 * node.plan_range):

                child.psi4supply[w][0] = []
                child.psi4supply[w][3] = []

        # lotid����Aleaf_node����肵�A�o�א�ship2node�ɏo�ׂ��邱�Ƃ́A
        # ���ׂĂ̎qnode�ɏo�ׂ��邱�ƂɂȂ�

        # ************************************
        # setting mother_confirmed_S
        # ************************************
        # ����node���ł̎qnode�ւ̓W�J
        for w in range(53 * node.plan_range):

            confirmed_S_lots = node.psi4supply[w][0]  # �e�̊m��o��confS lot

            # �o�א�node����肵��

            # ��ʂɂ́A���L��LT shift�����E�E�E�E�E
            # �o�א�� ETA = LT_shift(ETD) ��P place_lot
            # �H������ ETA = SS_shift(ETD) ��S place_lot

            # �{���f���ł́A�A���H�� = modal_node��z�肵�āE�E�E�E�E
            # �o�א�� ETA = �o�׌�ETD        ��P place_lot
            # �H������ ETA = LT&SS_shift(ETD) ��S place_lot
            # �Ƃ����C�r�c�ȃ��f����`�E�E�E�E�E

            # �����I��PO=INVOICE�Ƃ����l�����ɖ߂��ׂ������E�E�E�E�E
            #
            # modal shift��modeling��LT_shift�Ƃ̊g���ōl����???
            # modal = BOAT/AIR/QURIE
            # LT_shift(modal, w, ,,,,

            for lot in confirmed_S_lots:

                if lot == []:

                    pass

                else:

                    # *********************************************************
                    # child#ship2node = find_node_to_ship(node, lot)
                    # lotid����leaf_node��pointer��Ԃ�
                    leaf_node_name = extract_node_name(lot)

                    leaf_node = nodes[leaf_node_name]

                    # ���[���炠��nodeA�܂�leaf_node�܂ł�node_list��path�ŕԂ�

                    current_path = []
                    path = []

                    path = find_path_to_leaf_with_parent(node, leaf_node, current_path)

                    # nodes_list���t�ɂЂ�����Ԃ�
                    path.reverse()

                    # �o�א�node��nodeA�̎�node�Apath[1]�ɂȂ�
                    ship2node_name = path[1]

                    ship2node = nodes[ship2node_name]

                    # ������supply plan���X�V���Ă���
                    # �o�א�node��PSI��P��S�ɁAconfirmed_S����lot��by lot�Œu��
                    #place_P_in_supply(w, ship2node, lot)
                    place_P_in_supply_LT(w, ship2node, lot)

    for child in node.children:

        feedback_psi_lists(child, nodes)
        #feedback_psi_lists(child, node_psi_dict, nodes)






def copy_P_demand2supply(node): # TOBE 240926
#def update_child_PS(node): # TOBE 240926

    # �����I��.copy����B
    plan_len = 53 * node.plan_range
    for w in range(0, plan_len):

        node.psi4supply[w][3] = node.psi4demand[w][3].copy()



def PULL_process(node):
    # *******************************************
    # decouple node�́Apull_S�ŏo�׎w������
    # *******************************************

    #@241002 child�ŁA�enode�̊m��S=�m��P=demand��P�Ōv�Z�ς�
    # copy S&P demand2supply for PULL
    copy_S_demand2supply(node)
    copy_P_demand2supply(node)


    # ������node��PS2I�Ŋm�肷��
    node.calcPS2I4supply()  # calc_psi with PULL_S&P

    print(f"PULL_process applied to {node.name}")



def apply_pull_process(node):

    #@241002 MOVE
    #PULL_process(node)

    for child in node.children:


        PULL_process(child)


        apply_pull_process(child)




def copy_S_demand2supply(node): # TOBE 240926
#def update_child_PS(node): # TOBE 240926

    # �����I��.copy����B
    plan_len = 53 * node.plan_range
    for w in range(0, plan_len):

        node.psi4supply[w][0] = node.psi4demand[w][0].copy()




def PUSH_process(node):


    # ***************
    # decoupl node�ɓ����čŏ���calcPS2I�ŏ�Ԃ𐮂���
    # ***************
    node.calcPS2I4supply()  # calc_psi with PULL_S


    # STOP STOP
    ##@241002 decoupling node�̂�pullS�Ŋm��ship
    ## *******************************************
    ## decouple node�́Apull_S�ŏo�׎w������
    ## *******************************************
    ## copy S demand2supply
    #copy_S_demand2supply(node)
    #
    ## ������node��PS2I�Ŋm�肷��
    #node.calcPS2I4supply()  # calc_psi with PUSH_S


    print(f"PUSH_process applied to {node.name}")





def push_pull_all_psi2i_decouple4supply5(node, decouple_nodes):

    if node.name in decouple_nodes:

        # ***************
        # decoupl node�ɓ����čŏ���calcPS2I�ŏ�Ԃ𐮂���
        # ***************
        node.calcPS2I4supply()  # calc_psi with PULL_S


        #@241002 decoupling node�̂�pullS�Ŋm��ship
        # *******************************************
        # decouple node�́Apull_S�ŏo�׎w������
        # *******************************************
        copy_S_demand2supply(node)

        PUSH_process(node)         # supply SP2I���Ă����

        apply_pull_process(node)   # demandS�ɐ؂�ւ�

    else:

        PUSH_process(node)

        for child in node.children:

            push_pull_all_psi2i_decouple4supply5(child, decouple_nodes)





def map_psi_lots2df(node, D_S_flag, psi_lots):
    if D_S_flag == "demand":
        matrix = node.psi4demand
    elif D_S_flag == "supply":
        matrix = node.psi4supply
    else:
        print("error: wrong D_S_flag is defined")
        return pd.DataFrame()

    for week, row in enumerate(matrix):
        for scoip, lots in enumerate(row):
            for step_no, lot_id in enumerate(lots):
                psi_lots.append([node.name, week, scoip, step_no, lot_id])

    for child in node.children:
        map_psi_lots2df(child, D_S_flag, psi_lots)

    columns = ["node_name", "week", "s-co-i-p", "step_no", "lot_id"]
    df = pd.DataFrame(psi_lots, columns=columns)
    return df





# **************************
# collect_psi_data
# **************************
def collect_psi_data(node, D_S_flag, week_start, week_end, psi_data):
    if D_S_flag == "demand":
        psi_lots = []
        df_demand_plan = map_psi_lots2df(node, D_S_flag, psi_lots)
        df_init = df_demand_plan
    elif D_S_flag == "supply":
        psi_lots = []
        df_supply_plan = map_psi_lots2df(node, D_S_flag, psi_lots)
        df_init = df_supply_plan
    else:
        print("error: D_S_flag should be demand or supply")
        return

    condition1 = df_init["node_name"] == node.name
    condition2 = (df_init["week"] >= week_start) & (df_init["week"] <= week_end)
    df = df_init[condition1 & condition2]

    line_data_2I = df[df["s-co-i-p"].isin([2])]
    bar_data_0S = df[df["s-co-i-p"] == 0]
    bar_data_3P = df[df["s-co-i-p"] == 3]

    line_plot_data_2I = line_data_2I.groupby("week")["lot_id"].count()
    bar_plot_data_3P = bar_data_3P.groupby("week")["lot_id"].count()
    bar_plot_data_0S = bar_data_0S.groupby("week")["lot_id"].count()



    # �m�[�h��REVENUE��PROFIT���l�̌ܓ�

    # root_out_opt����root_outbound�̐��E�֕ϊ�����
    #@241225 be checked

    #@ STOP
    ##@ TEST node_opt��node_origin�ɁArevenue��profit������ǉ�
    #revenue = round(node.revenue)
    #profit  = round(node.profit)


    #@241225 STOP "self.nodes_outbound"��scope�ɂȂ�
    #node_origin = self.nodes_outbound[node.name]
    #

    revenue = round(node.eval_cs_price_sales_shipped)
    profit = round(node.eval_cs_profit)



    # PROFIT_RATIO���v�Z���Ďl�̌ܓ�
    profit_ratio = round((profit / revenue) * 100, 1) if revenue != 0 else 0

    psi_data.append((node.name, revenue, profit, profit_ratio, line_plot_data_2I, bar_plot_data_3P, bar_plot_data_0S))




# node is "node_opt"
def collect_psi_data_opt(node, node_out, D_S_flag, week_start, week_end, psi_data):
    if D_S_flag == "demand":
        psi_lots = []
        df_demand_plan = map_psi_lots2df(node, D_S_flag, psi_lots)
        df_init = df_demand_plan
    elif D_S_flag == "supply":
        psi_lots = []
        df_supply_plan = map_psi_lots2df(node, D_S_flag, psi_lots)
        df_init = df_supply_plan
    else:
        print("error: D_S_flag should be demand or supply")
        return

    condition1 = df_init["node_name"] == node.name
    condition2 = (df_init["week"] >= week_start) & (df_init["week"] <= week_end)
    df = df_init[condition1 & condition2]

    line_data_2I = df[df["s-co-i-p"].isin([2])]
    bar_data_0S = df[df["s-co-i-p"] == 0]
    bar_data_3P = df[df["s-co-i-p"] == 3]

    line_plot_data_2I = line_data_2I.groupby("week")["lot_id"].count()
    bar_plot_data_3P = bar_data_3P.groupby("week")["lot_id"].count()
    bar_plot_data_0S = bar_data_0S.groupby("week")["lot_id"].count()



    # �m�[�h��REVENUE��PROFIT���l�̌ܓ�

    # root_out_opt����root_outbound�̐��E�֕ϊ�����
    #@241225 be checked

    #@ STOP
    ##@ TEST node_opt��node_origin�ɁArevenue��profit������ǉ�
    #revenue = round(node.revenue)
    #profit  = round(node.profit)


    #@241225 STOP "self.nodes_outbound"��scope�ɂȂ�
    #node_origin = self.nodes_outbound[node.name]
    #

    # node��opt����out�ɐ؂�ւ�
    revenue = round(node_out.eval_cs_price_sales_shipped)
    profit = round(node_out.eval_cs_profit)



    # PROFIT_RATIO���v�Z���Ďl�̌ܓ�
    profit_ratio = round((profit / revenue) * 100, 1) if revenue != 0 else 0

    psi_data.append((node.name, revenue, profit, profit_ratio, line_plot_data_2I, bar_plot_data_3P, bar_plot_data_0S))





# gui/app.py
class PSIPlannerApp:
    def __init__(self, root, config):
        self.root = root
        self.config = config
        self.root.title(self.config.APP_NAME)

        self.tree_structure = None
        self.setup_ui()

        # PSI planner
        self.outbound_data = None
        self.inbound_data = None

        self.root_node_outbound = None
        self.nodes_outbound = None
        self.leaf_nodes_out = []

        self.root_node_inbound = None
        self.nodes_inbound = None
        self.leaf_nodes_in = []

        self.total_revenue = 0
        self.total_profit = 0
        self.profit_ratio = 0

        # View settings
        self.G = None
        self.pos_E2E = None
        self.fig_network = None
        self.ax_network = None

        # Initialize parameters
        self.initialize_parameters()

    def setup_ui(self):
        print("Setting up the UI")

        # Custom font
        custom_font = tkfont.Font(family="Helvetica", size=12)

        # Menu configuration
        self.root.option_add('*TearOffMenu*Font', custom_font)
        self.root.option_add('*Menu*Font', custom_font)

        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="OPEN: select Directory", command=self.load_data_files)
        file_menu.add_command(label="EXIT", command=self.on_exit)
        menubar.add_cascade(label=" FILE ", menu=file_menu)

        self.root.config(menu=menubar)

        # Main frame
        self.frame = ttk.Frame(self.root)
        self.frame.pack(side=tk.LEFT, fill=tk.Y)

        # Lot size entry
        self.lot_size_label = ttk.Label(self.frame, text="Lot Size:")
        self.lot_size_label.pack(side=tk.TOP)
        self.lot_size_entry = ttk.Entry(self.frame, width=10)
        self.lot_size_entry.pack(side=tk.TOP)
        self.lot_size_entry.insert(0, str(self.config.DEFAULT_LOT_SIZE))

        # Plan Year Start entry
        self.plan_year_label = ttk.Label(self.frame, text="Plan Year Start:")
        self.plan_year_label.pack(side=tk.TOP)
        self.plan_year_entry = ttk.Entry(self.frame, width=10)
        self.plan_year_entry.pack(side=tk.TOP)
        self.plan_year_entry.insert(0, str(self.config.DEFAULT_START_YEAR))

        # Plan Range entry
        self.plan_range_label = ttk.Label(self.frame, text="Plan Range:")
        self.plan_range_label.pack(side=tk.TOP)
        self.plan_range_entry = ttk.Entry(self.frame, width=10)
        self.plan_range_entry.pack(side=tk.TOP)
        self.plan_range_entry.insert(0, str(self.config.DEFAULT_PLAN_RANGE))

        # Demand Planning button
        self.Demand_Pl_button = ttk.Button(self.frame, text="Demand Planning", command=self.demand_planning)
        self.Demand_Pl_button.pack(side=tk.TOP)

        # Plot area
        self.plot_frame = ttk.Frame(self.root)
        self.plot_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Network Graph frame
        self.network_frame = ttk.Frame(self.plot_frame)
        self.network_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.fig_network, self.ax_network = plt.subplots(figsize=(5, 10))  # Adjusted size
        self.canvas_network = FigureCanvasTkAgg(self.fig_network, master=self.network_frame)
        self.canvas_network.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Scrollable PSI Graph frame
        self.psi_frame = ttk.Frame(self.plot_frame)
        self.psi_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.canvas_psi = tk.Canvas(self.psi_frame)
        self.scrollbar = ttk.Scrollbar(self.psi_frame, orient="vertical", command=self.canvas_psi.yview)
        self.scrollable_frame = ttk.Frame(self.canvas_psi)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas_psi.configure(
                scrollregion=self.canvas_psi.bbox("all")
            )
        )

        self.canvas_psi.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas_psi.configure(yscrollcommand=self.scrollbar.set)
        self.canvas_psi.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def initialize_parameters(self):
        print("Initializing parameters")
        self.lot_size = self.config.DEFAULT_LOT_SIZE
        self.plan_year_st = self.config.DEFAULT_START_YEAR
        self.plan_range = self.config.DEFAULT_PLAN_RANGE

        self.market_potential = 0
        self.target_share = self.config.DEFAULT_TARGET_SHARE
        self.total_supply = 0




# gui/app.py
class PSIPlannerApp:
    def __init__(self, root, config):
    #def __init__(self, root):

        self.root = root
        self.config = config
        self.root.title(self.config.APP_NAME)
        
        self.tree_structure = None
        self.setup_ui()


        #@ STOP moved to config.py
        #self.lot_size     = 2000      # �����l
        #self.plan_year_st = 2022      # �����l
        #self.plan_range   = 2         # �����l
        #self.pre_proc_LT  = 13        # �����l 13week = 3month
        #self.market_potential = 0     # �����l 0
        #self.target_share     = 0.5   # �����l 0.5 = 50%
        #self.total_supply     = 0     # �����l 0

        self.setup_ui()


        # ********************************
        # PSI planner
        # ********************************
        self.outbound_data = None
        self.inbound_data = None

        # PySI tree
        self.root_node_outbound = None
        self.nodes_outbound     = None
        self.leaf_nodes_out     = []

        self.root_node_inbound  = None
        self.nodes_inbound      = None
        self.leaf_nodes_in      = []

        self.root_node_out_opt  = None
        self.nodes_out_opt      = None
        self.leaf_nodes_opt     = []


        self.optimized_root     = None
        self.optimized_nodes    = None


        # Evaluation on PSI
        self.total_revenue = 0
        self.total_profit  = 0
        self.profit_ratio  = 0

        # view
        self.G = None

        # Optimise
        self.Gdm_structure = None

        self.Gdm = None
        self.Gsp = None

        self.pos_E2E = None

        self.flowDict_opt = {} #None
        self.flowCost_opt = {} #None

        self.total_supply_plan = 0

        # loading files
        self.directory = None
        self.load_directory = None

        self.base_leaf_name = None

        # supply_plan / decoupling / buffer stock
        self.decouple_node_dic = {}

        self.decouple_node_selected = []
















    def setup_ui(self):

        print("setup_ui is processing")

        # �t�H���g�̐ݒ�
        custom_font = tkfont.Font(family="Helvetica", size=12)

        # ���j���[�S�̂̃t�H���g�T�C�Y��ݒ�
        self.root.option_add('*TearOffMenu*Font', custom_font)
        self.root.option_add('*Menu*Font', custom_font)

        # ���j���[�o�[�̍쐬
        menubar = tk.Menu(self.root)

        # �X�^�C���̐ݒ�
        style = ttk.Style()
        style.configure("TMenubutton", font=("Helvetica", 12))

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="OPEN: select Directory", command=self.load_data_files)
        file_menu.add_separator()
        file_menu.add_command(label="SAVE: to Directory", command=self.save_to_directory)

        file_menu.add_command(label="LOAD: from Directory", command=self.load_from_directory)

        file_menu.add_separator()
        file_menu.add_command(label="EXIT", command=self.on_exit)
        menubar.add_cascade(label=" FILE  ", menu=file_menu)

        # Optimize Parameter menu
        optimize_menu = tk.Menu(menubar, tearoff=0)
        optimize_menu.add_command(label="Weight: Cost Stracture on Common Plan Unit", command=self.show_cost_stracture_bar_graph)
        optimize_menu.add_command(label="Capacity: Market Demand", command=self.show_month_data_csv)
        menubar.add_cascade(label="Optimize Parameter", menu=optimize_menu)



        # Report menu
        report_menu = tk.Menu(menubar, tearoff=0)

        report_menu.add_command(label="Outbound: PSI to csv file", command=self.outbound_psi_to_csv)

        report_menu.add_command(label="Outbound: Lot by Lot data to csv", command=self.outbound_lot_by_lot_to_csv)

        report_menu.add_separator()

        report_menu.add_command(label="Inbound: PSI to csv file", command=self.inbound_psi_to_csv)
        report_menu.add_command(label="Inbound: Lot by Lot data to csv", command=self.inbound_lot_by_lot_to_csv)

        report_menu.add_separator()

        report_menu.add_separator()

        report_menu.add_command(label="Value Chain: Cost Stracture a Lot", command=self.lot_cost_structure_to_csv)

        report_menu.add_command(label="Supply Chain: Revenue Profit", command=self.supplychain_performance_to_csv)



        #report_menu.add_separator()
        #
        #report_menu.add_command(label="PSI for Excel", command=self.psi_for_excel)


        menubar.add_cascade(label="Report", menu=report_menu)




        # 3D overview menu
        overview_menu = tk.Menu(menubar, tearoff=0)
        overview_menu.add_command(label="3D overview on Lots based Plan", command=self.show_3d_overview)
        menubar.add_cascade(label="3D overview", menu=overview_menu)

        self.root.config(menu=menubar)

        # �t���[���̍쐬
        self.frame = ttk.Frame(self.root)
        self.frame.pack(side=tk.LEFT, fill=tk.Y)

        # Lot size entry
        self.lot_size_label = ttk.Label(self.frame, text="Lot Size:")
        self.lot_size_label.pack(side=tk.TOP)
        self.lot_size_entry = ttk.Entry(self.frame, width=10)
        self.lot_size_entry.pack(side=tk.TOP)

        #@250117 UPDATE
        self.lot_size_entry.insert(0, str(self.config.DEFAULT_LOT_SIZE))  # �����l��ݒ�
        #self.lot_size_entry.insert(0, str(self.lot_size))  # �����l��ݒ�

        # Plan Year Start entry
        self.plan_year_label = ttk.Label(self.frame, text="Plan Year Start:")
        self.plan_year_label.pack(side=tk.TOP)
        self.plan_year_entry = ttk.Entry(self.frame, width=10)
        self.plan_year_entry.pack(side=tk.TOP)


        self.plan_year_entry.insert(0, str(self.config.DEFAULT_START_YEAR))  # �����l��ݒ�
        #self.plan_year_entry.insert(0, str(self.plan_year_st))  # �����l��ݒ�

        # Plan Range entry
        self.plan_range_label = ttk.Label(self.frame, text="Plan Range:")
        self.plan_range_label.pack(side=tk.TOP)
        self.plan_range_entry = ttk.Entry(self.frame, width=10)
        self.plan_range_entry.pack(side=tk.TOP)


        self.plan_range_entry.insert(0, str(self.config.DEFAULT_PLAN_RANGE))  # �����l��ݒ�
        #self.plan_range_entry.insert(0, str(self.plan_range))  # �����l��ݒ�

        # 1�s���̋󔒂�ǉ�
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Demand Planning buttons
        self.Demand_Pl_button = ttk.Button(self.frame, text="Demand Planning", command=self.demand_planning)
        self.Demand_Pl_button.pack(side=tk.TOP)

        # Plan Year Start entry
        self.pre_proc_LT_label = ttk.Label(self.frame, text="pre_proc_LT:")
        self.pre_proc_LT_label.pack(side=tk.TOP)
        self.pre_proc_LT_entry = ttk.Entry(self.frame, width=10)
        self.pre_proc_LT_entry.pack(side=tk.TOP)


        self.pre_proc_LT_entry.insert(0, str(self.config.DEFAULT_PRE_PROC_LT))  # �����l��ݒ�
        #self.pre_proc_LT_entry.insert(0, str(self.pre_proc_LT))  # �����l��ݒ�

        # Demand Leveling button
        self.Demand_Lv_button = ttk.Button(self.frame, text="Demand Leveling", command=self.demand_leveling)
        self.Demand_Lv_button.pack(side=tk.TOP)

        # add a blank line
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Supply Planning button
        self.supply_planning_button = ttk.Button(self.frame, text="Supply Planning ", command=self.supply_planning)
        self.supply_planning_button.pack(side=tk.TOP)

        # add a blank line
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Eval_buffer_stock buttons
        self.eval_buffer_stock_button = ttk.Button(self.frame, text="Eval Buffer Stock ", command=self.eval_buffer_stock)
        self.eval_buffer_stock_button.pack(side=tk.TOP)

        # add a blank line
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Optimize Network button
        self.optimize_button = ttk.Button(self.frame, text="OPT Supply Alloc", command=self.optimize_network)
        self.optimize_button.pack(side=tk.TOP)

        # Plot area divided into two frames
        self.plot_frame = ttk.Frame(self.root)
        self.plot_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Network Graph frame
        self.network_frame = ttk.Frame(self.plot_frame)
        self.network_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # New Frame for Parameters at the top of the network_frame
        self.param_frame = ttk.Frame(self.network_frame)
        self.param_frame.pack(side=tk.TOP, fill=tk.X)


        # Global Market Potential, Target Share, Total Supply Plan input fields arranged horizontally
        self.gmp_label = tk.Label(self.param_frame, text="Market Potential:", background='navy', foreground='white', font=('Helvetica', 10, 'bold'))
        self.gmp_label.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.gmp_entry = tk.Entry(self.param_frame, width=10)
        self.gmp_entry.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)

        self.ts_label = tk.Label(self.param_frame, text="TargetShare(%)", background='navy', foreground='white', font=('Helvetica', 10, 'bold'))
        self.ts_label.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.ts_entry = tk.Entry(self.param_frame, width=5)
        self.ts_entry.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)



        self.ts_entry.insert(0, self.config.DEFAULT_TARGET_SHARE * 100) # �����l
        #self.ts_entry.insert(0, self.target_share * 100) # �����l

        self.tsp_label = tk.Label(self.param_frame, text="Total Supply:", background='navy', foreground='white', font=('Helvetica', 10, 'bold'))
        self.tsp_label.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.tsp_entry = tk.Entry(self.param_frame, width=10)
        self.tsp_entry.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.tsp_entry.config(bg='lightgrey')  # �w�i�F��lightgrey�ɐݒ�









        # �C�x���g�o�C���f�B���O
        self.gmp_entry.bind("<Return>", self.update_total_supply_plan)
        self.ts_entry.bind("<Return>", self.update_total_supply_plan)

        self.fig_network, self.ax_network = plt.subplots(figsize=(4, 8))  # �������k��
        self.canvas_network = FigureCanvasTkAgg(self.fig_network, master=self.network_frame)
        self.canvas_network.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.fig_network.subplots_adjust(left=0.05, right=0.95, top=0.95, bottom=0.05)

        # Evaluation result area
        self.eval_frame = ttk.Frame(self.plot_frame)
        self.eval_frame.pack(side=tk.TOP, fill=tk.X, padx=(20, 0))  # �������ɔz�u

        # Total Revenue
        self.total_revenue_label = ttk.Label(self.eval_frame, text="Total Revenue:", background='darkgreen', foreground='white', font=('Helvetica', 10, 'bold'))
        self.total_revenue_label.pack(side=tk.LEFT, padx=5, pady=10)
        self.total_revenue_entry = ttk.Entry(self.eval_frame, width=10, state='readonly')
        self.total_revenue_entry.pack(side=tk.LEFT, padx=5, pady=10)

        # Total Profit
        self.total_profit_label = ttk.Label(self.eval_frame, text="Total Profit:", background='darkgreen', foreground='white', font=('Helvetica', 10, 'bold'))
        self.total_profit_label.pack(side=tk.LEFT, padx=5, pady=10)
        self.total_profit_entry = ttk.Entry(self.eval_frame, width=10, state='readonly')
        self.total_profit_entry.pack(side=tk.LEFT, padx=5, pady=10)



        # Profit Ratio
        self.profit_ratio_label = ttk.Label(self.eval_frame, text="Profit Ratio:", background='darkgreen', foreground='white', font=('Helvetica', 10, 'bold'))
        self.profit_ratio_label.pack(side=tk.LEFT, padx=5, pady=10)
        self.profit_ratio_entry = ttk.Entry(self.eval_frame, width=10, state='readonly')
        self.profit_ratio_entry.pack(side=tk.LEFT, padx=5, pady=10)

        # PSI Graph scroll frame (moved to below evaluation area)
        self.psi_frame = ttk.Frame(self.plot_frame)
        self.psi_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.canvas_psi = tk.Canvas(self.psi_frame)
        self.scrollbar = ttk.Scrollbar(self.psi_frame, orient="vertical", command=self.canvas_psi.yview)
        self.scrollable_frame = ttk.Frame(self.canvas_psi)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas_psi.configure(
                scrollregion=self.canvas_psi.bbox("all")
            )
        )

        self.canvas_psi.create_window((0, 0), window=self.scrollable_frame, anchor="nw")

        self.canvas_psi.configure(yscrollcommand=self.scrollbar.set)

        self.canvas_psi.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        # �������֐����Ăяo���ăp�����[�^�ݒ�
        self.initialize_parameters()




    def update_total_supply_plan(self, event):
        try:
            market_potential = float(self.gmp_entry.get().replace(',', ''))
            target_share = float(self.ts_entry.get().replace('%', ''))/100
        except ValueError:
            print("Invalid input for Global Market Potential or Target Share.")
            return

        # Total Supply Plan�̍Čv�Z
        total_supply_plan = round(market_potential * target_share)

        self.total_supply_plan = total_supply_plan

        # Total Supply Plan�t�B�[���h�̍X�V
        self.tsp_entry.config(state='normal')
        self.tsp_entry.delete(0, tk.END)
        self.tsp_entry.insert(0, "{:,}".format(total_supply_plan))  # 3�����ɃJ���}��؂�ŕ\��
        self.tsp_entry.config(state='normal')



    def initialize_parameters(self): 
        # Calculation and setting of Global Market Potential
        market_potential = getattr(self, 'market_potential', self.config.DEFAULT_MARKET_POTENTIAL)  # Including initial settings

        self.gmp_entry.delete(0, tk.END)
        self.gmp_entry.insert(0, "{:,}".format(market_potential))  # Display with comma separated thousands

        # Initial setting of Target Share (already set in setup_ui)

        # Calculation and setting of Total Supply Plan
        target_share = float(self.ts_entry.get().replace('%', ''))/100  # Convert string to float and remove %

        total_supply_plan = round(market_potential * target_share)
        self.tsp_entry.delete(0, tk.END)
        self.tsp_entry.insert(0, "{:,}".format(total_supply_plan))  # Display with comma separated thousands

        #self.global_market_potential  = global_market_potential

        self.market_potential         = market_potential
        self.target_share             = target_share           
        self.total_supply_plan        = total_supply_plan
        print(f"At initialization - market_potential: {self.market_potential}, target_share: {self.target_share}")  # Add log




    def setup_ui_OLD(self):
        # Create menu bar
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Load Tree Structure", command=self.load_tree_structure)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        optimize_menu = tk.Menu(menubar, tearoff=0)
        optimize_menu.add_command(label="View Optimization Graph", command=self.view_nx_matlib4opt)
        menubar.add_cascade(label="Optimize", menu=optimize_menu)

        self.root.config(menu=menubar)

        # Split frames for network graph and PSI graph
        self.left_frame = tk.Frame(self.root, width=500)
        self.left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.right_frame = tk.Frame(self.root, width=500)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Network Graph Area
        self.fig_network, self.ax_network = plt.subplots()
        self.canvas_network = FigureCanvasTkAgg(self.fig_network, master=self.left_frame)
        self.canvas_network.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # PSI Graph Area
        self.fig_psi, self.ax_psi = plt.subplots()
        self.canvas_psi = FigureCanvasTkAgg(self.fig_psi, master=self.right_frame)
        self.canvas_psi.get_tk_widget().pack(fill=tk.BOTH, expand=True)



# ******************************
# actions
# ******************************



    def load_data_files(self):
        directory = filedialog.askdirectory(title="Select Data Directory")

        if directory:
            try:
                self.lot_size = int(self.lot_size_entry.get())
                self.plan_year_st = int(self.plan_year_entry.get())
                self.plan_range = int(self.plan_range_entry.get())
            except ValueError:
                print("Invalid input for lot size, plan year start, or plan range. Using default values.")

            self.outbound_data = []
            self.inbound_data = []

            data_file_list = os.listdir(directory)

            self.directory = directory
            self.load_directory = directory

            if "profile_tree_outbound.csv" in data_file_list:
                file_path = os.path.join(directory, "profile_tree_outbound.csv")
                nodes_outbound = {}
                nodes_outbound, root_node_name_out = create_tree_set_attribute(file_path)
                root_node_outbound = nodes_outbound[root_node_name_out]

                def make_leaf_nodes(node, leaf_list):
                    if not node.children:
                        leaf_list.append(node.name)
                    for child in node.children:
                        make_leaf_nodes(child, leaf_list)
                    return leaf_list

                leaf_nodes_out = make_leaf_nodes(root_node_outbound, [])
                self.nodes_outbound = nodes_outbound
                self.root_node_outbound = root_node_outbound
                self.leaf_nodes_out = leaf_nodes_out
                set_positions(root_node_outbound)
                set_parent_all(root_node_outbound)
                print_parent_all(root_node_outbound)
            else:
                print("error: profile_tree_outbound.csv is missed")

            if "profile_tree_inbound.csv" in data_file_list:
                file_path = os.path.join(directory, "profile_tree_inbound.csv")
                nodes_inbound = {}
                nodes_inbound, root_node_name_in = create_tree_set_attribute(file_path)
                root_node_inbound = nodes_inbound[root_node_name_in]
                self.nodes_inbound = nodes_inbound
                self.root_node_inbound = root_node_inbound
                set_positions(root_node_inbound)
                set_parent_all(root_node_inbound)
                print_parent_all(root_node_inbound)
            else:
                print("error: profile_tree_inbound.csv is missed")

            if "node_cost_table_outbound.csv" in data_file_list:
                file_path = os.path.join(directory, "node_cost_table_outbound.csv")
                read_set_cost(file_path, nodes_outbound)
            else:
                print("error: node_cost_table_outbound.csv is missed")

            if "node_cost_table_inbound.csv" in data_file_list:
                file_path = os.path.join(directory, "node_cost_table_inbound.csv")
                read_set_cost(file_path, nodes_inbound)
            else:
                print("error: node_cost_table_inbound.csv is missed")

            if "S_month_data.csv" in data_file_list:
                in_file_path = os.path.join(directory, "S_month_data.csv")

                df_weekly, plan_range, plan_year_st = process_monthly_demand(in_file_path, self.lot_size)
                #df_weekly, plan_range, plan_year_st = trans_month2week2lot_id_list(in_file_path, self.lot_size)

                self.plan_year_st = plan_year_st
                self.plan_range = plan_range
                self.plan_year_entry.delete(0, tk.END)
                self.plan_year_entry.insert(0, str(self.plan_year_st))
                self.plan_range_entry.delete(0, tk.END)
                self.plan_range_entry.insert(0, str(self.plan_range))
                out_file_path = os.path.join(directory, "S_iso_week_data.csv")
                df_weekly.to_csv(out_file_path, index=False)
            else:
                print("error: S_month_data.csv is missed")

            root_node_outbound.set_plan_range_lot_counts(plan_range, plan_year_st)
            root_node_inbound.set_plan_range_lot_counts(plan_range, plan_year_st)

            node_psi_dict_Ot4Dm = make_psi_space_dict(root_node_outbound, {}, plan_range)
            node_psi_dict_Ot4Sp = make_psi_space_dict(root_node_outbound, {}, plan_range)
            node_psi_dict_In4Dm = make_psi_space_dict(root_node_inbound, {}, plan_range)
            node_psi_dict_In4Sp = make_psi_space_dict(root_node_inbound, {}, plan_range)
            set_dict2tree_psi(root_node_outbound, "psi4demand", node_psi_dict_Ot4Dm)
            set_dict2tree_psi(root_node_outbound, "psi4supply", node_psi_dict_Ot4Sp)
            set_dict2tree_psi(root_node_inbound, "psi4demand", node_psi_dict_In4Dm)
            set_dict2tree_psi(root_node_inbound, "psi4supply", node_psi_dict_In4Sp)



            #set_df_Slots2psi4demand(self.root_node_outbound, df_weekly)
            set_df_Slots2psi4demand(root_node_outbound, df_weekly)

            print("Data files loaded successfully.")




# **** A PART of ORIGINAL load_data_files *****

        def count_lots_on_S_psi4demand(node, S_list):
                if not node.children:
                        for w_psi in node.psi4demand:
                                S_list.append(w_psi[0])
                for child in node.children:
                        count_lots_on_S_psi4demand(child, S_list)
                return S_list

        S_list = []
        year_lots_list4S = []
        S_list = count_lots_on_S_psi4demand(root_node_outbound, S_list)

        #@250117 STOP
        #plan_year_st = year_st

        for yyyy in range(plan_year_st, plan_year_st + plan_range + 1):
                year_lots4S = count_lots_yyyy(S_list, str(yyyy))
                year_lots_list4S.append(year_lots4S)

        self.market_potential = year_lots_list4S[1]
        print("self.market_potential", self.market_potential)

        self.total_supply_plan = round(self.market_potential * self.target_share)
        print("self.total_supply_plan", self.total_supply_plan)

        for filename in os.listdir(directory):
                if filename.endswith(".csv"):
                        filepath = os.path.join(directory, filename)
                        print(f"Loading file: {filename}")
                        if "outbound" in filename.lower():
                                self.outbound_data.append(pd.read_csv(filepath))
                        elif "inbound" in filename.lower():
                                self.inbound_data.append(pd.read_csv(filepath))
        print("Outbound files loaded.")
        print("Inbound files loaded.")

        def find_node_with_cost_standard_flag(nodes, flag_value):
                for node_name, node in nodes.items():
                        if node.cost_standard_flag == flag_value:
                                return node_name, node
                return None, None

        node_name, base_leaf = find_node_with_cost_standard_flag(nodes_outbound, 100)
        self.base_leaf_name = node_name

        if node_name is None:
                print("NO cost_standard = 100 in profile")
        else:
                print(f"Node name: {node_name}, Base leaf: {base_leaf}")

        root_price = set_price_leaf2root(base_leaf, self.root_node_outbound, 100)
        print("root_price", root_price)
        set_value_chain_outbound(root_price, self.root_node_outbound)



        print("demand_planning execute")




        calc_all_psi2i4demand(self.root_node_outbound)

        self.update_evaluation_results()
        self.decouple_node_selected = []
        self.view_nx_matlib_stop_draw()



        print("Demand Leveling execute")
        year_st = self.plan_year_st
        year_end = year_st + self.plan_range - 1
        pre_prod_week = self.config.DEFAULT_PRE_PROC_LT
        #pre_prod_week = self.pre_proc_LT

        demand_leveling_on_ship(self.root_node_outbound, pre_prod_week, year_st, year_end)

        self.root_node_outbound.calcS2P_4supply()
        self.root_node_outbound.calcPS2I4supply()
        feedback_psi_lists(self.root_node_outbound, self.nodes_outbound)

        self.update_evaluation_results()
        self.psi_backup_to_file(self.root_node_outbound, 'psi_backup.pkl')
        self.view_nx_matlib_stop_draw()



        print("Supply planning with Decoupling points")
        self.root_node_outbound = self.psi_restore_from_file('psi_backup.pkl')

        if not self.decouple_node_selected:
                nodes_decouple_all = make_nodes_decouple_all(self.root_node_outbound)
                print("nodes_decouple_all", nodes_decouple_all)
                decouple_node_names = nodes_decouple_all[-2]
        else:
                decouple_node_names = self.decouple_node_selected

        push_pull_all_psi2i_decouple4supply5(self.root_node_outbound, decouple_node_names)


        # eval area
        self.update_evaluation_results()


        # network area
        self.decouple_node_selected = decouple_node_names
        self.view_nx_matlib4opt()



        # PSI area
        self.root.after(1000, self.show_psi("outbound", "supply"))



        # ****************************
        # market potential Graph viewing
        # ****************************
        self.initialize_parameters()

# **** A PART of ORIGINAL load_data_files END *****


# **** call_backs *****

    def save_to_directory(self):
        pass
    
    def load_from_directory(self):
        pass
    



    def on_exit(self):
        # �m�F�_�C�A���O�̕\��
        if messagebox.askokcancel("Quit", "Do you really want to exit?"):
            # �S�ẴX���b�h���I��
            for thread in threading.enumerate():
                if thread is not threading.main_thread():
                    thread.join(timeout=1)
    
            #for widget in self.root.winfo_children():
            #    widget.destroy()
    
            #self.root.destroy()
            self.root.quit()


    






    def show_cost_stracture_bar_graph(self):
        pass
    
    def show_month_data_csv(self):
        pass
    
    def outbound_psi_to_csv(self):
        pass
    
    def outbound_lot_by_lot_to_csv(self):
        pass
    
    def inbound_psi_to_csv(self):
        pass
    
    def inbound_lot_by_lot_to_csv(self):
        pass
    
    def lot_cost_structure_to_csv(self):
        pass
    
    def supplychain_performance_to_csv(self):
        pass
    
    def psi_for_excel(self):
        pass
    
    def show_3d_overview(self):
        pass
    
    def demand_planning(self):
        pass
    
#    def demand_leveling(self):
#        pass

    def demand_leveling(self):

        # Demand Leveling logic here
        print("Demand Leveling executed.")


        # *********************************
        # Demand LEVELing on shipping yard / with pre_production week
        # *********************************

        year_st  = 2020
        year_end = 2021

        year_st  = self.plan_year_st
        year_end = year_st + self.plan_range - 1

        pre_prod_week = self.pre_proc_LT

        # STOP
        #year_st = df_capa_year["year"].min()
        #year_end = df_capa_year["year"].max()

        # root_node_outbound��supply��"S"�݂̂𕽏������Đ������Ă���
        demand_leveling_on_ship(self.root_node_outbound, pre_prod_week, year_st, year_end)


        # root_node_outbound��supply��"PSI"�𐶐����Ă���
        ##@241114 KEY CODE
        self.root_node_outbound.calcS2P_4supply()  #mother plant��confirm S=> P
        self.root_node_outbound.calcPS2I4supply()  #mother plant��PS=>I


        #@241114 KEY CODE
        # ***************************************
        # ����3�@�s�x��parent search�����s setPS_on_ship2node
        # ***************************************
        feedback_psi_lists(self.root_node_outbound, self.nodes_outbound)


        #feedback_psi_lists(self.root_node_outbound, node_psi_dict_Ot4Sp, self.nodes_outbound)


        # STOP
        #decouple_node_names = [] # initial PUSH with NO decouple node
        ##push_pull_on_decouple
        #push_pull_all_psi2i_decouple4supply5(
        #    self.root_node_outbound,
        #    decouple_node_names )



        #@241114 KEY CODE
        #@240903

        #calc_all_psi2i4demand(self.root_node_outbound)
        #calc_all_psi2i4supply(self.root_node_outbound)


        self.update_evaluation_results()

        # PSI�v��̏�����Ԃ��o�b�N�A�b�v
        self.psi_backup_to_file(self.root_node_outbound, 'psi_backup.pkl')


        self.view_nx_matlib()

        

        self.root.after(1000, self.show_psi("outbound", "supply"))
        #self.root.after(1000, self.show_psi_graph)




    def psi_backup(self, node, status_name):
        return copy.deepcopy(node)

    def psi_restore(self, node_backup, status_name):
        return copy.deepcopy(node_backup)

    def psi_backup_to_file(self, node, filename):
        with open(filename, 'wb') as file:
            pickle.dump(node, file)

    def psi_restore_from_file(self, filename):
        with open(filename, 'rb') as file:
            node_backup = pickle.load(file)
        return node_backup




    def supply_planning(self):
        pass
    
    def eval_buffer_stock(self):
        pass
    
    def optimize_network(self):
        pass

# **** 19 call_backs END*****



    def load_tree_structure(self):
        try:
            file_path = filedialog.askopenfilename(title="Select Tree Structure File")
            if not file_path:
                return
            # Placeholder for loading tree structure
            self.tree_structure = nx.DiGraph()
            self.tree_structure.add_edge("Root", "Child1")
            self.tree_structure.add_edge("Root", "Child2")
            messagebox.showinfo("Success", "Tree structure loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load tree structure: {e}")




    def view_nx_matlib4opt(self):
        G = nx.DiGraph()
        Gdm_structure = nx.DiGraph()
        Gsp = nx.DiGraph()

        self.G = G
        self.Gdm_structure = Gdm_structure
        self.Gsp = Gsp

        pos_E2E, G, Gdm, Gsp = self.show_network_E2E_matplotlib(
            self.root_node_outbound, self.nodes_outbound,
            self.root_node_inbound, self.nodes_inbound,
            G, Gdm_structure, Gsp
        )

        self.pos_E2E = pos_E2E

        #self.draw_network4opt(G, Gdm, Gsp, pos_E2E)

        # �O���t�`��֐����Ăяo��  �œK���[�g��Ԑ��ŕ\��

        print("load_from_directory self.flowDict_opt", self.flowDict_opt)

        self.draw_network4opt(G, Gdm_structure, Gsp, pos_E2E, self.flowDict_opt)





    def draw_network4opt(self, G, Gdm, Gsp, pos_E2E, flowDict_opt):

        ## �����̎����N���A
        #self.ax_network.clear()

    #def draw_network(self, G, Gdm, Gsp, pos_E2E):

        self.ax_network.clear()  # �}���N���A


        print("draw_network4opt: self.total_revenue", self.total_revenue)
        print("draw_network4opt: self.total_profit", self.total_profit)

        # �]�����ʂ̍X�V
        ttl_revenue = self.total_revenue
        ttl_profit = self.total_profit
        ttl_profit_ratio = (ttl_profit / ttl_revenue) if ttl_revenue != 0 else 0

        # �l�̌ܓ����ĕ\��
        total_revenue = round(ttl_revenue)
        total_profit = round(ttl_profit)
        profit_ratio = round(ttl_profit_ratio * 100, 1)  # �p�[�Z���g�\��


        #ax.set_title(f'Node: {node_name} | REVENUE: {revenue:,} | PROFIT: {profit:,} | PROFIT_RATIO: {profit_ratio}%', fontsize=8)


        # �^�C�g����ݒ�
        self.ax_network.set_title(f'PySI\nOptimized Supply Chain Network\nREVENUE: {total_revenue:,} | PROFIT: {total_profit:,} | PROFIT_RATIO: {profit_ratio}%', fontsize=10)


        print("ax_network.set_title: total_revenue", total_revenue)
        print("ax_network.set_title: total_profit", total_profit)


#".format(total_revenue, total_profit))


        self.ax_network.axis('off')








        # �m�[�h�̌`��ƐF���`
        node_shapes = ['v' if node in self.decouple_node_selected else 'o' for node in G.nodes()]
        node_colors = ['brown' if node in self.decouple_node_selected else 'lightblue' for node in G.nodes()]


        # �m�[�h�̕`��
        for node, shape, color in zip(G.nodes(), node_shapes, node_colors):

            nx.draw_networkx_nodes(G, pos_E2E, nodelist=[node], node_size=50, node_color=color, node_shape=shape, ax=self.ax_network)


        # �G�b�W�̕`��
        for edge in G.edges():
            if edge[0] == "procurement_office" or edge[1] == "sales_office":
                edge_color = 'lightgrey'  # "procurement_office"�܂���"sales_office"�ɐڑ�����G�b�W��lightgrey
            elif edge in Gdm.edges():
                edge_color = 'blue'  # outbound�iGdm�j�̃G�b�W�͐�
            elif edge in Gsp.edges():
                edge_color = 'green'  # inbound�iGsp�j�̃G�b�W�͗�
            else:
                edge_color = 'lightgrey'  # ���̑���lightgrey

            nx.draw_networkx_edges(G, pos_E2E, edgelist=[edge], edge_color=edge_color, arrows=False, ax=self.ax_network, width=0.5)

        # �œK��path�̐Ԑ��\��
        for from_node, flows in flowDict_opt.items():
            for to_node, flow in flows.items():
                if flow > 0:
                    # "G"�̏�ɕ`��
                    nx.draw_networkx_edges(self.G, self.pos_E2E, edgelist=[(from_node, to_node)], ax=self.ax_network, edge_color='red', arrows=False, width=0.5)

        # �m�[�h���x���̕`��
        node_labels = {node: f"{node}" for node in G.nodes()}
        nx.draw_networkx_labels(G, pos_E2E, labels=node_labels, font_size=6, ax=self.ax_network)





        # ***************************
        # title and axis
        # ***************************
        #plt.title("Supply Chain Network end2end")

        #@ STOOOOOOOP
        #plt.title("Optimized Supply Chain Network")
        #self.ax_network.axis('off')  # �����\���ɂ���


        # �L�����o�X���X�V
        self.canvas_network.draw()








    def view_nx_matlib4opt_OLD(self):
        try:
            if self.tree_structure is None:
                raise ValueError("Tree structure is not loaded.")

            self.ax_network.clear()
            nx.draw(self.tree_structure, with_labels=True, ax=self.ax_network)
            self.canvas_network.draw()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display optimization graph: {e}")




    def update_evaluation_results(self):


        # Evaluation on PSI
        self.total_revenue = 0
        self.total_profit  = 0
        self.profit_ratio  = 0


        # ***********************
        # This is a simple Evaluation process with "cost table"
        # ***********************


#@241120 STOP
#        self.eval_plan()
#
#    def eval_plan(self):



        # �݌ɌW���̌v�Z
        # I_cost_coeff = I_total_qty_init / I_total_qty_planned
        #
        # �v�悳�ꂽ�݌ɃR�X�g�̎Z��
        # I_cost_planned = I_cost_init * I_cost_coeff
    
    
        # by node evaluation Revenue / Cost / Profit
        # "eval_xxx" = "lot_counts" X "cs_xxx" that is from cost_table
        # Inventory cost has �W�� = I_total on Demand/ I_total on Supply
    
    
        #self.total_revenue = 0
        #self.total_profit  = 0
    
        #eval_supply_chain_cost(self.root_node_outbound)
        #self.eval_supply_chain_cost(self.root_node_outbound)
    
        #eval_supply_chain_cost(self.root_node_inbound)
        #self.eval_supply_chain_cost(self.root_node_inbound)

        #@ CONTEXT �O���[�o���ϐ� STOP
        ## �T�v���C�`�F�[���S�̂̃R�X�g��]��
        #eval_supply_chain_cost(self.root_node_outbound, self)
        #eval_supply_chain_cost(self.root_node_inbound, self)

        #@ RUN local�ϐ�
        # �T�v���C�`�F�[���̕]�����J�n
        self.total_revenue, self.total_profit = eval_supply_chain_cost(self.root_node_outbound)

        ttl_revenue = self.total_revenue
        ttl_profit  = self.total_profit

        if ttl_revenue == 0:
            ttl_profit_ratio = 0
        else:
            ttl_profit_ratio = ttl_profit / ttl_revenue

        # �l�̌ܓ����ĕ\�� 
        total_revenue = round(ttl_revenue) 
        total_profit = round(ttl_profit) 
        profit_ratio = round(ttl_profit_ratio*100, 1) # �p�[�Z���g�\��

        print("total_revenue", total_revenue)
        print("total_profit", total_profit)
        print("profit_ratio", profit_ratio)


#total_revenue 343587
#total_profit 32205
#profit_ratio 9.4


        self.total_revenue_entry.config(state='normal')
        self.total_revenue_entry.delete(0, tk.END)
        self.total_revenue_entry.insert(0, f"{total_revenue:,}")
        #self.total_revenue_entry.insert(0, str(kpi_results["total_revenue"]))
        self.total_revenue_entry.config(state='readonly')


        self.total_profit_entry.config(state='normal')
        self.total_profit_entry.delete(0, tk.END)
        self.total_profit_entry.insert(0, f"{total_profit:,}")
        #self.total_profit_entry.insert(0, str(kpi_results["total_profit"]))
        self.total_profit_entry.config(state='readonly')


        self.profit_ratio_entry.config(state='normal')
        self.profit_ratio_entry.delete(0, tk.END)
        self.profit_ratio_entry.insert(0, f"{profit_ratio}%")
        self.profit_ratio_entry.config(state='readonly')

        # ��ʂ��ĕ`��
        self.total_revenue_entry.update_idletasks()
        self.total_profit_entry.update_idletasks()
        self.profit_ratio_entry.update_idletasks()



# ******************************************
# visualize graph
# ******************************************

    def view_nx_matlib_stop_draw(self):
        G = nx.DiGraph()
        Gdm_structure = nx.DiGraph()
        Gsp = nx.DiGraph()

        print(f"view_nx_matlib before show_network_E2E_matplotlib self.decouple_node_selected: {self.decouple_node_selected}")

        pos_E2E, G, Gdm_structure, Gsp = self.show_network_E2E_matplotlib(
            self.root_node_outbound, self.nodes_outbound,
            self.root_node_inbound, self.nodes_inbound,
            G, Gdm_structure, Gsp
        )

        self.pos_E2E = pos_E2E

        print(f"view_nx_matlib after show_network_E2E_matplotlib self.decouple_node_selected: {self.decouple_node_selected}")

        self.G = G
        self.Gdm_structure = Gdm_structure
        self.Gsp = Gsp

        #@250106 STOP draw
        #self.draw_network(self.G, self.Gdm_structure, self.Gsp, self.pos_E2E)



    def initialize_graphs(self):
        self.G = nx.DiGraph()
        self.Gdm_structure = nx.DiGraph()
        self.Gsp = nx.DiGraph()


    # ***************************
    # make network with NetworkX
    # ***************************



    def show_network_E2E_matplotlib(self,
            root_node_outbound, nodes_outbound, 
            root_node_inbound, nodes_inbound, 
            G, Gdm, Gsp):
        
        # Original code's logic to process and set up the network
        root_node_name_out = root_node_outbound.name 
        root_node_name_in  = root_node_inbound.name

        total_demand =0
        total_demand = set_leaf_demand(root_node_outbound, total_demand)
        #total_demand = self.set_leaf_demand(root_node_outbound, total_demand)
        print("average_total_demand", total_demand)
        print("root_node_outbound.nx_demand", root_node_outbound.nx_demand)

        root_node_outbound.nx_demand = total_demand  
        root_node_inbound.nx_demand = total_demand  

        G_add_nodes_from_tree(root_node_outbound, G)
        #self.G_add_nodes_from_tree(root_node_outbound, G)
        G_add_nodes_from_tree_skip_root(root_node_inbound, root_node_name_in, G)
        #self.G_add_nodes_from_tree_skip_root(root_node_inbound, root_node_name_in, G)

        G.add_node("sales_office", demand=total_demand)
        G.add_node(root_node_outbound.name, demand=0)
        G.add_node("procurement_office", demand=(-1 * total_demand))

        G_add_edge_from_tree(root_node_outbound, G)
        #self.G_add_edge_from_tree(root_node_outbound, G)
        supplyers_capacity = root_node_inbound.nx_demand * 2 
        G_add_edge_from_inbound_tree(root_node_inbound, supplyers_capacity, G)
        #self.G_add_edge_from_inbound_tree(root_node_inbound, supplyers_capacity, G)

        G_add_nodes_from_tree(root_node_outbound, Gdm)
        #self.G_add_nodes_from_tree(root_node_outbound, Gdm)
        Gdm.add_node(root_node_outbound.name, demand = (-1 * total_demand))
        Gdm.add_node("sales_office", demand = total_demand)
        Gdm_add_edge_sc2nx_outbound(root_node_outbound, Gdm)
        #self.Gdm_add_edge_sc2nx_outbound(root_node_outbound, Gdm)

        G_add_nodes_from_tree(root_node_inbound, Gsp)
        #self.G_add_nodes_from_tree(root_node_inbound, Gsp)
        Gsp.add_node("procurement_office", demand = (-1 * total_demand))
        Gsp.add_node(root_node_inbound.name, demand = total_demand)
        Gsp_add_edge_sc2nx_inbound(root_node_inbound, Gsp)
        #self.Gsp_add_edge_sc2nx_inbound(root_node_inbound, Gsp)

        pos_E2E = make_E2E_positions(root_node_outbound, root_node_inbound)
        #pos_E2E = self.make_E2E_positions(root_node_outbound, root_node_inbound)
        pos_E2E = tune_hammock(pos_E2E, nodes_outbound, nodes_inbound)
        #pos_E2E = self.tune_hammock(pos_E2E, nodes_outbound, nodes_inbound)

        return pos_E2E, G, Gdm, Gsp



    def show_network_E2E_matplotlib_with_self(self):
        root_node_outbound = self.root_node_outbound
        nodes_outbound = self.nodes_outbound
        root_node_inbound = self.root_node_inbound
        nodes_inbound = self.nodes_inbound
        return self.show_network_E2E_matplotlib(
            root_node_outbound, nodes_outbound, 
            root_node_inbound, nodes_inbound, 
            self.G, self.Gdm_structure, self.Gsp
        )


# ******************************************
# optimize network graph
# ******************************************


    def optimize(self, G_opt):
        self.reset_optimization_params(G_opt)
        self.set_optimization_params(G_opt)
        self.run_optimization(G_opt)
        print("run_optimization self.flowDict_opt", self.flowDict_opt)
        self.reset_optimized_path(G_opt)
        self.add_optimized_path(G_opt, self.flowDict_opt)
        print("Optimized Path:", self.flowDict_opt)
        print("Optimized Cost:", self.flowCost_opt)
    




# *************************
# PSI graph 
# *************************
    def show_psi(self, bound, layer):
        print("making PSI graph data...")
    
        week_start = 1
        week_end = self.plan_range * 53
    
        psi_data = []
    
        if bound not in ["outbound", "inbound"]:
            print("error: outbound or inbound must be defined for PSI layer")
            return
    
        if layer not in ["demand", "supply"]:
            print("error: demand or supply must be defined for PSI layer")
            return
    
        def traverse_nodes(node):
            for child in node.children:
                traverse_nodes(child)
            collect_psi_data(node, layer, week_start, week_end, psi_data)
    
        if bound == "outbound":
            traverse_nodes(self.root_node_outbound)
        else:
            traverse_nodes(self.root_node_inbound)
    
        fig, axs = plt.subplots(len(psi_data), 1, figsize=(5, len(psi_data) * 1))  # figsize�̍���������ɒZ���ݒ�
    
        if len(psi_data) == 1:
            axs = [axs]

        for ax, (node_name, revenue, profit, profit_ratio, line_plot_data_2I, bar_plot_data_3P, bar_plot_data_0S) in zip(axs, psi_data):
            ax2 = ax.twinx()
    
            ax.bar(line_plot_data_2I.index, line_plot_data_2I.values, color='r', alpha=0.6)
            ax.bar(bar_plot_data_3P.index, bar_plot_data_3P.values, color='g', alpha=0.6)
            ax2.plot(bar_plot_data_0S.index, bar_plot_data_0S.values, color='b')
    
            ax.set_ylabel('I&P Lots', fontsize=8)
            ax2.set_ylabel('S Lots', fontsize=8)
            ax.set_title(f'Node: {node_name} | REVENUE: {revenue:,} | PROFIT: {profit:,} | PROFIT_RATIO: {profit_ratio}%', fontsize=8)
    
        fig.tight_layout(pad=0.5)
    
        print("making PSI figure and widget...")

        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
    
        canvas_psi = FigureCanvasTkAgg(fig, master=self.scrollable_frame)
        canvas_psi.draw()
        canvas_psi.get_tk_widget().pack(fill=tk.BOTH, expand=True)



