#250114gui_app.py

# gui/app.py

# ********************************
# library import
# ********************************
import os
import shutil
import threading

import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import font as tkfont, Tk, Menu, ttk

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import networkx as nx




# ********************************
# PySI library import
# ********************************
from utils.config import Config

from network.tree import *
#from network.tree import create_tree_set_attribute
#from network.tree import set_node_costs

from utils.file_io import *
#from utils.file_io import load_cost_table
#from utils.file_io import load_monthly_demand

from PSI_plan.demand_generate import convert_monthly_to_weekly



#def trans_month2week2lot_id_list(file_name, lot_size)
def process_monthly_demand(file_name, lot_size):
    """
    Process monthly demand data and convert to weekly data.

    Parameters:
        file_name (str): Path to the monthly demand file.
        lot_size (int): Lot size for allocation.

    Returns:
        pd.DataFrame: Weekly demand data with ISO weeks and lot IDs.
    """
    monthly_data = load_monthly_demand(file_name)
    if monthly_data.empty:
        print("Error: Failed to load monthly demand data.")
        return None

    return convert_monthly_to_weekly(monthly_data, lot_size)




def read_set_cost(file_path, nodes_outbound):
    """
    Load cost table from file and set node costs.

    Parameters:
        file_path (str): Path to the cost table file.
        nodes_outbound (dict): Dictionary of outbound nodes.

    Returns:
        None
    """
    cost_table = load_cost_table(file_path)
    if cost_table is not None:
        set_node_costs(cost_table, nodes_outbound)




# gui/app.py
class PSIPlannerApp:
    def __init__(self, root, config):
    #def __init__(self, root):

        self.root = root
        self.config = config
        self.root.title(self.config.APP_NAME)
        
        self.tree_structure = None
        self.setup_ui()




    def setup_ui(self):

        print("setup_ui is processing")

        # �t�H���g�̐ݒ�
        custom_font = tkfont.Font(family="Helvetica", size=12)

        # ���j���[�S�̂̃t�H���g�T�C�Y��ݒ�
        self.root.option_add('*TearOffMenu*Font', custom_font)
        self.root.option_add('*Menu*Font', custom_font)

        # ���j���[�o�[�̍쐬
        menubar = tk.Menu(self.root)

        # �X�^�C���̐ݒ�
        style = ttk.Style()
        style.configure("TMenubutton", font=("Helvetica", 12))

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="OPEN: select Directory", command=self.load_data_files)
        file_menu.add_separator()
        file_menu.add_command(label="SAVE: to Directory", command=self.save_to_directory)

        file_menu.add_command(label="LOAD: from Directory", command=self.load_from_directory)

        file_menu.add_separator()
        file_menu.add_command(label="EXIT", command=self.on_exit)
        menubar.add_cascade(label=" FILE  ", menu=file_menu)

        # Optimize Parameter menu
        optimize_menu = tk.Menu(menubar, tearoff=0)
        optimize_menu.add_command(label="Weight: Cost Stracture on Common Plan Unit", command=self.show_cost_stracture_bar_graph)
        optimize_menu.add_command(label="Capacity: Market Demand", command=self.show_month_data_csv)
        menubar.add_cascade(label="Optimize Parameter", menu=optimize_menu)



        # Report menu
        report_menu = tk.Menu(menubar, tearoff=0)

        report_menu.add_command(label="Outbound: PSI to csv file", command=self.outbound_psi_to_csv)

        report_menu.add_command(label="Outbound: Lot by Lot data to csv", command=self.outbound_lot_by_lot_to_csv)

        report_menu.add_separator()

        report_menu.add_command(label="Inbound: PSI to csv file", command=self.inbound_psi_to_csv)
        report_menu.add_command(label="Inbound: Lot by Lot data to csv", command=self.inbound_lot_by_lot_to_csv)

        report_menu.add_separator()

        report_menu.add_separator()

        report_menu.add_command(label="Value Chain: Cost Stracture a Lot", command=self.lot_cost_structure_to_csv)

        report_menu.add_command(label="Supply Chain: Revenue Profit", command=self.supplychain_performance_to_csv)



        #report_menu.add_separator()
        #
        #report_menu.add_command(label="PSI for Excel", command=self.psi_for_excel)


        menubar.add_cascade(label="Report", menu=report_menu)




        # 3D overview menu
        overview_menu = tk.Menu(menubar, tearoff=0)
        overview_menu.add_command(label="3D overview on Lots based Plan", command=self.show_3d_overview)
        menubar.add_cascade(label="3D overview", menu=overview_menu)

        self.root.config(menu=menubar)

        # �t���[���̍쐬
        self.frame = ttk.Frame(self.root)
        self.frame.pack(side=tk.LEFT, fill=tk.Y)

        # Lot size entry
        self.lot_size_label = ttk.Label(self.frame, text="Lot Size:")
        self.lot_size_label.pack(side=tk.TOP)
        self.lot_size_entry = ttk.Entry(self.frame, width=10)
        self.lot_size_entry.pack(side=tk.TOP)

        #@250117 UPDATE
        self.lot_size_entry.insert(0, str(self.config.DEFAULT_LOT_SIZE))  # �����l��ݒ�
        #self.lot_size_entry.insert(0, str(self.lot_size))  # �����l��ݒ�

        # Plan Year Start entry
        self.plan_year_label = ttk.Label(self.frame, text="Plan Year Start:")
        self.plan_year_label.pack(side=tk.TOP)
        self.plan_year_entry = ttk.Entry(self.frame, width=10)
        self.plan_year_entry.pack(side=tk.TOP)


        self.plan_year_entry.insert(0, str(self.config.DEFAULT_START_YEAR))  # �����l��ݒ�
        #self.plan_year_entry.insert(0, str(self.plan_year_st))  # �����l��ݒ�

        # Plan Range entry
        self.plan_range_label = ttk.Label(self.frame, text="Plan Range:")
        self.plan_range_label.pack(side=tk.TOP)
        self.plan_range_entry = ttk.Entry(self.frame, width=10)
        self.plan_range_entry.pack(side=tk.TOP)


        self.plan_range_entry.insert(0, str(self.config.DEFAULT_PLAN_RANGE))  # �����l��ݒ�
        #self.plan_range_entry.insert(0, str(self.plan_range))  # �����l��ݒ�

        # 1�s���̋󔒂�ǉ�
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Demand Planning buttons
        self.Demand_Pl_button = ttk.Button(self.frame, text="Demand Planning", command=self.demand_planning)
        self.Demand_Pl_button.pack(side=tk.TOP)

        # Plan Year Start entry
        self.pre_proc_LT_label = ttk.Label(self.frame, text="pre_proc_LT:")
        self.pre_proc_LT_label.pack(side=tk.TOP)
        self.pre_proc_LT_entry = ttk.Entry(self.frame, width=10)
        self.pre_proc_LT_entry.pack(side=tk.TOP)


        self.pre_proc_LT_entry.insert(0, str(self.config.DEFAULT_PRE_PROC_LT))  # �����l��ݒ�
        #self.pre_proc_LT_entry.insert(0, str(self.pre_proc_LT))  # �����l��ݒ�

        # Demand Leveling button
        self.Demand_Lv_button = ttk.Button(self.frame, text="Demand Leveling", command=self.demand_leveling)
        self.Demand_Lv_button.pack(side=tk.TOP)

        # add a blank line
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Supply Planning button
        self.supply_planning_button = ttk.Button(self.frame, text="Supply Planning ", command=self.supply_planning)
        self.supply_planning_button.pack(side=tk.TOP)

        # add a blank line
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Eval_buffer_stock buttons
        self.eval_buffer_stock_button = ttk.Button(self.frame, text="Eval Buffer Stock ", command=self.eval_buffer_stock)
        self.eval_buffer_stock_button.pack(side=tk.TOP)

        # add a blank line
        self.space_label = ttk.Label(self.frame, text="")
        self.space_label.pack(side=tk.TOP)

        # Optimize Network button
        self.optimize_button = ttk.Button(self.frame, text="OPT Supply Alloc", command=self.optimize_network)
        self.optimize_button.pack(side=tk.TOP)

        # Plot area divided into two frames
        self.plot_frame = ttk.Frame(self.root)
        self.plot_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Network Graph frame
        self.network_frame = ttk.Frame(self.plot_frame)
        self.network_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # New Frame for Parameters at the top of the network_frame
        self.param_frame = ttk.Frame(self.network_frame)
        self.param_frame.pack(side=tk.TOP, fill=tk.X)


        # Global Market Potential, Target Share, Total Supply Plan input fields arranged horizontally
        self.gmp_label = tk.Label(self.param_frame, text="Market Potential:", background='navy', foreground='white', font=('Helvetica', 10, 'bold'))
        self.gmp_label.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.gmp_entry = tk.Entry(self.param_frame, width=10)
        self.gmp_entry.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)

        self.ts_label = tk.Label(self.param_frame, text="TargetShare(%)", background='navy', foreground='white', font=('Helvetica', 10, 'bold'))
        self.ts_label.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.ts_entry = tk.Entry(self.param_frame, width=5)
        self.ts_entry.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)



        self.ts_entry.insert(0, self.config.DEFAULT_TARGET_SHARE * 100) # �����l
        #self.ts_entry.insert(0, self.target_share * 100) # �����l

        self.tsp_label = tk.Label(self.param_frame, text="Total Supply:", background='navy', foreground='white', font=('Helvetica', 10, 'bold'))
        self.tsp_label.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.tsp_entry = tk.Entry(self.param_frame, width=10)
        self.tsp_entry.pack(side=tk.LEFT, fill=tk.X, padx=5, pady=10)
        self.tsp_entry.config(bg='lightgrey')  # �w�i�F��lightgrey�ɐݒ�









        # �C�x���g�o�C���f�B���O
        self.gmp_entry.bind("<Return>", self.update_total_supply_plan)
        self.ts_entry.bind("<Return>", self.update_total_supply_plan)

        self.fig_network, self.ax_network = plt.subplots(figsize=(4, 8))  # �������k��
        self.canvas_network = FigureCanvasTkAgg(self.fig_network, master=self.network_frame)
        self.canvas_network.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.fig_network.subplots_adjust(left=0.05, right=0.95, top=0.95, bottom=0.05)

        # Evaluation result area
        self.eval_frame = ttk.Frame(self.plot_frame)
        self.eval_frame.pack(side=tk.TOP, fill=tk.X, padx=(20, 0))  # �������ɔz�u

        # Total Revenue
        self.total_revenue_label = ttk.Label(self.eval_frame, text="Total Revenue:", background='darkgreen', foreground='white', font=('Helvetica', 10, 'bold'))
        self.total_revenue_label.pack(side=tk.LEFT, padx=5, pady=10)
        self.total_revenue_entry = ttk.Entry(self.eval_frame, width=10, state='readonly')
        self.total_revenue_entry.pack(side=tk.LEFT, padx=5, pady=10)

        # Total Profit
        self.total_profit_label = ttk.Label(self.eval_frame, text="Total Profit:", background='darkgreen', foreground='white', font=('Helvetica', 10, 'bold'))
        self.total_profit_label.pack(side=tk.LEFT, padx=5, pady=10)
        self.total_profit_entry = ttk.Entry(self.eval_frame, width=10, state='readonly')
        self.total_profit_entry.pack(side=tk.LEFT, padx=5, pady=10)



        # Profit Ratio
        self.profit_ratio_label = ttk.Label(self.eval_frame, text="Profit Ratio:", background='darkgreen', foreground='white', font=('Helvetica', 10, 'bold'))
        self.profit_ratio_label.pack(side=tk.LEFT, padx=5, pady=10)
        self.profit_ratio_entry = ttk.Entry(self.eval_frame, width=10, state='readonly')
        self.profit_ratio_entry.pack(side=tk.LEFT, padx=5, pady=10)

        # PSI Graph scroll frame (moved to below evaluation area)
        self.psi_frame = ttk.Frame(self.plot_frame)
        self.psi_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.canvas_psi = tk.Canvas(self.psi_frame)
        self.scrollbar = ttk.Scrollbar(self.psi_frame, orient="vertical", command=self.canvas_psi.yview)
        self.scrollable_frame = ttk.Frame(self.canvas_psi)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas_psi.configure(
                scrollregion=self.canvas_psi.bbox("all")
            )
        )

        self.canvas_psi.create_window((0, 0), window=self.scrollable_frame, anchor="nw")

        self.canvas_psi.configure(yscrollcommand=self.scrollbar.set)

        self.canvas_psi.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        # �������֐����Ăяo���ăp�����[�^�ݒ�
        self.initialize_parameters()




    def update_total_supply_plan(self, event):
        try:
            market_potential = float(self.gmp_entry.get().replace(',', ''))
            target_share = float(self.ts_entry.get().replace('%', ''))/100
        except ValueError:
            print("Invalid input for Global Market Potential or Target Share.")
            return

        # Total Supply Plan�̍Čv�Z
        total_supply_plan = round(market_potential * target_share)

        self.total_supply_plan = total_supply_plan

        # Total Supply Plan�t�B�[���h�̍X�V
        self.tsp_entry.config(state='normal')
        self.tsp_entry.delete(0, tk.END)
        self.tsp_entry.insert(0, "{:,}".format(total_supply_plan))  # 3�����ɃJ���}��؂�ŕ\��
        self.tsp_entry.config(state='normal')



    def initialize_parameters(self): 
        # Calculation and setting of Global Market Potential
        market_potential = getattr(self, 'market_potential', self.config.DEFAULT_MARKET_POTENTIAL)  # Including initial settings

        self.gmp_entry.delete(0, tk.END)
        self.gmp_entry.insert(0, "{:,}".format(market_potential))  # Display with comma separated thousands

        # Initial setting of Target Share (already set in setup_ui)

        # Calculation and setting of Total Supply Plan
        target_share = float(self.ts_entry.get().replace('%', ''))/100  # Convert string to float and remove %

        total_supply_plan = round(market_potential * target_share)
        self.tsp_entry.delete(0, tk.END)
        self.tsp_entry.insert(0, "{:,}".format(total_supply_plan))  # Display with comma separated thousands

        #self.global_market_potential  = global_market_potential

        self.market_potential         = market_potential
        self.target_share             = target_share           
        self.total_supply_plan        = total_supply_plan
        print(f"At initialization - market_potential: {self.market_potential}, target_share: {self.target_share}")  # Add log




    def setup_ui_OLD(self):
        # Create menu bar
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Load Tree Structure", command=self.load_tree_structure)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        optimize_menu = tk.Menu(menubar, tearoff=0)
        optimize_menu.add_command(label="View Optimization Graph", command=self.view_nx_matlib4opt)
        menubar.add_cascade(label="Optimize", menu=optimize_menu)

        self.root.config(menu=menubar)

        # Split frames for network graph and PSI graph
        self.left_frame = tk.Frame(self.root, width=500)
        self.left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.right_frame = tk.Frame(self.root, width=500)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Network Graph Area
        self.fig_network, self.ax_network = plt.subplots()
        self.canvas_network = FigureCanvasTkAgg(self.fig_network, master=self.left_frame)
        self.canvas_network.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # PSI Graph Area
        self.fig_psi, self.ax_psi = plt.subplots()
        self.canvas_psi = FigureCanvasTkAgg(self.fig_psi, master=self.right_frame)
        self.canvas_psi.get_tk_widget().pack(fill=tk.BOTH, expand=True)



# ******************************
# actions
# ******************************



    def load_data_files(self):
        directory = filedialog.askdirectory(title="Select Data Directory")

        if directory:
            try:
                self.lot_size = int(self.lot_size_entry.get())
                self.plan_year_st = int(self.plan_year_entry.get())
                self.plan_range = int(self.plan_range_entry.get())
            except ValueError:
                print("Invalid input for lot size, plan year start, or plan range. Using default values.")

            self.outbound_data = []
            self.inbound_data = []

            data_file_list = os.listdir(directory)

            self.directory = directory
            self.load_directory = directory

            if "profile_tree_outbound.csv" in data_file_list:
                file_path = os.path.join(directory, "profile_tree_outbound.csv")
                nodes_outbound = {}
                nodes_outbound, root_node_name_out = create_tree_set_attribute(file_path)
                root_node_outbound = nodes_outbound[root_node_name_out]

                def make_leaf_nodes(node, leaf_list):
                    if not node.children:
                        leaf_list.append(node.name)
                    for child in node.children:
                        make_leaf_nodes(child, leaf_list)
                    return leaf_list

                leaf_nodes_out = make_leaf_nodes(root_node_outbound, [])
                self.nodes_outbound = nodes_outbound
                self.root_node_outbound = root_node_outbound
                self.leaf_nodes_out = leaf_nodes_out
                set_positions(root_node_outbound)
                set_parent_all(root_node_outbound)
                print_parent_all(root_node_outbound)
            else:
                print("error: profile_tree_outbound.csv is missed")

            if "profile_tree_inbound.csv" in data_file_list:
                file_path = os.path.join(directory, "profile_tree_inbound.csv")
                nodes_inbound = {}
                nodes_inbound, root_node_name_in = create_tree_set_attribute(file_path)
                root_node_inbound = nodes_inbound[root_node_name_in]
                self.nodes_inbound = nodes_inbound
                self.root_node_inbound = root_node_inbound
                set_positions(root_node_inbound)
                set_parent_all(root_node_inbound)
                print_parent_all(root_node_inbound)
            else:
                print("error: profile_tree_inbound.csv is missed")

            if "node_cost_table_outbound.csv" in data_file_list:
                file_path = os.path.join(directory, "node_cost_table_outbound.csv")
                read_set_cost(file_path, nodes_outbound)
            else:
                print("error: node_cost_table_outbound.csv is missed")

            if "node_cost_table_inbound.csv" in data_file_list:
                file_path = os.path.join(directory, "node_cost_table_inbound.csv")
                read_set_cost(file_path, nodes_inbound)
            else:
                print("error: node_cost_table_inbound.csv is missed")

            if "S_month_data.csv" in data_file_list:
                in_file_path = os.path.join(directory, "S_month_data.csv")
                df_weekly, plan_range, plan_year_st = trans_month2week2lot_id_list(in_file_path, self.lot_size)
                self.plan_year_st = plan_year_st
                self.plan_range = plan_range
                self.plan_year_entry.delete(0, tk.END)
                self.plan_year_entry.insert(0, str(self.plan_year_st))
                self.plan_range_entry.delete(0, tk.END)
                self.plan_range_entry.insert(0, str(self.plan_range))
                out_file_path = os.path.join(directory, "S_iso_week_data.csv")
                df_weekly.to_csv(out_file_path, index=False)
            else:
                print("error: S_month_data.csv is missed")

            root_node_outbound.set_plan_range_lot_counts(plan_range, plan_year_st)
            root_node_inbound.set_plan_range_lot_counts(plan_range, plan_year_st)

            node_psi_dict_Ot4Dm = make_psi_space_dict(root_node_outbound, {}, plan_range)
            node_psi_dict_Ot4Sp = make_psi_space_dict(root_node_outbound, {}, plan_range)
            node_psi_dict_In4Dm = make_psi_space_dict(root_node_inbound, {}, plan_range)
            node_psi_dict_In4Sp = make_psi_space_dict(root_node_inbound, {}, plan_range)
            set_dict2tree_psi(root_node_outbound, "psi4demand", node_psi_dict_Ot4Dm)
            set_dict2tree_psi(root_node_outbound, "psi4supply", node_psi_dict_Ot4Sp)
            set_dict2tree_psi(root_node_inbound, "psi4demand", node_psi_dict_In4Dm)
            set_dict2tree_psi(root_node_inbound, "psi4supply", node_psi_dict_In4Sp)

            set_df_Slots2psi4demand(root_node_outbound, df_weekly)
            print("Data files loaded successfully.")


# **** A PART of ORIGINAL load_data_files *****

        def count_lots_on_S_psi4demand(node, S_list):
                if not node.children:
                        for w_psi in node.psi4demand:
                                S_list.append(w_psi[0])
                for child in node.children:
                        count_lots_on_S_psi4demand(child, S_list)
                return S_list

        S_list = []
        year_lots_list4S = []
        S_list = count_lots_on_S_psi4demand(root_node_outbound, S_list)

        #@250117 STOP
        #plan_year_st = year_st

        for yyyy in range(plan_year_st, plan_year_st + plan_range + 1):
                year_lots4S = count_lots_yyyy(S_list, str(yyyy))
                year_lots_list4S.append(year_lots4S)

        self.market_potential = year_lots_list4S[1]
        print("self.market_potential", self.market_potential)

        self.total_supply_plan = round(self.market_potential * self.target_share)
        print("self.total_supply_plan", self.total_supply_plan)

        for filename in os.listdir(directory):
                if filename.endswith(".csv"):
                        filepath = os.path.join(directory, filename)
                        print(f"Loading file: {filename}")
                        if "outbound" in filename.lower():
                                self.outbound_data.append(pd.read_csv(filepath))
                        elif "inbound" in filename.lower():
                                self.inbound_data.append(pd.read_csv(filepath))
        print("Outbound files loaded.")
        print("Inbound files loaded.")

        def find_node_with_cost_standard_flag(nodes, flag_value):
                for node_name, node in nodes.items():
                        if node.cost_standard_flag == flag_value:
                                return node_name, node
                return None, None

        node_name, base_leaf = find_node_with_cost_standard_flag(nodes_outbound, 100)
        self.base_leaf_name = node_name

        if node_name is None:
                print("NO cost_standard = 100 in profile")
        else:
                print(f"Node name: {node_name}, Base leaf: {base_leaf}")

        root_price = set_price_leaf2root(base_leaf, self.root_node_outbound, 100)
        print("root_price", root_price)
        set_value_chain_outbound(root_price, self.root_node_outbound)

        print("demand_planning executed.")
        calc_all_psi2i4demand(self.root_node_outbound)
        self.update_evaluation_results()
        self.decouple_node_selected = []
        self.view_nx_matlib_stop_draw()

        print("Demand Leveling executed.")
        year_st = self.plan_year_st
        year_end = year_st + self.plan_range - 1
        pre_prod_week = self.pre_proc_LT

        demand_leveling_on_ship(self.root_node_outbound, pre_prod_week, year_st, year_end)
        self.root_node_outbound.calcS2P_4supply()
        self.root_node_outbound.calcPS2I4supply()
        feedback_psi_lists(self.root_node_outbound, self.nodes_outbound)
        self.update_evaluation_results()
        self.psi_backup_to_file(self.root_node_outbound, 'psi_backup.pkl')
        self.view_nx_matlib_stop_draw()

        print("Supply planning with Decoupling points")
        self.root_node_outbound = self.psi_restore_from_file('psi_backup.pkl')

        if not self.decouple_node_selected:
                nodes_decouple_all = make_nodes_decouple_all(self.root_node_outbound)
                print("nodes_decouple_all", nodes_decouple_all)
                decouple_node_names = nodes_decouple_all[-2]
        else:
                decouple_node_names = self.decouple_node_selected

        push_pull_all_psi2i_decouple4supply5(self.root_node_outbound, decouple_node_names)
        self.update_evaluation_results()
        self.decouple_node_selected = decouple_node_names
        self.view_nx_matlib4opt()
        self.root.after(1000, self.show_psi("outbound", "supply"))
        self.initialize_parameters()

# **** A PART of ORIGINAL load_data_files END *****


# **** call_backs *****

    def save_to_directory(self):
        pass
    
    def load_from_directory(self):
        pass
    
    def on_exit(self):
        pass
    
    def show_cost_stracture_bar_graph(self):
        pass
    
    def show_month_data_csv(self):
        pass
    
    def outbound_psi_to_csv(self):
        pass
    
    def outbound_lot_by_lot_to_csv(self):
        pass
    
    def inbound_psi_to_csv(self):
        pass
    
    def inbound_lot_by_lot_to_csv(self):
        pass
    
    def lot_cost_structure_to_csv(self):
        pass
    
    def supplychain_performance_to_csv(self):
        pass
    
    def psi_for_excel(self):
        pass
    
    def show_3d_overview(self):
        pass
    
    def demand_planning(self):
        pass
    
    def demand_leveling(self):
        pass
    
    def supply_planning(self):
        pass
    
    def eval_buffer_stock(self):
        pass
    
    def optimize_network(self):
        pass

# **** 19 call_backs END*****



    def load_tree_structure(self):
        try:
            file_path = filedialog.askopenfilename(title="Select Tree Structure File")
            if not file_path:
                return
            # Placeholder for loading tree structure
            self.tree_structure = nx.DiGraph()
            self.tree_structure.add_edge("Root", "Child1")
            self.tree_structure.add_edge("Root", "Child2")
            messagebox.showinfo("Success", "Tree structure loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load tree structure: {e}")


    def view_nx_matlib4opt(self):
        try:
            if self.tree_structure is None:
                raise ValueError("Tree structure is not loaded.")

            self.ax_network.clear()
            nx.draw(self.tree_structure, with_labels=True, ax=self.ax_network)
            self.canvas_network.draw()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display optimization graph: {e}")


