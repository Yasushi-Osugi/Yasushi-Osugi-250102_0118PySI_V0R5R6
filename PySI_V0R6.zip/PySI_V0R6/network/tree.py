#network_tree250114.py


# network/tree.py
from typing import List, Dict, Optional

from collections import defaultdict
from utils.file_io import read_tree_file
#from some_module import Node  # Node�N���X��K�؂ȏꏊ����C���|�[�g



class Node:
    def __init__(self, name: str):
        self.name = name
        self.children: List['Node'] = []
        self.parent: Optional['Node'] = None
        self.depth = 0
        self.width = 0
        self.lot_size = 0
        self.psi = []  # Placeholder for PSI data

    def add_child(self, child: 'Node'):
        """Add a child node to the current node."""
        self.children.append(child)
        child.parent = self

    def set_depth(self, depth: int):
        """Recursively set the depth of the node and its children."""
        self.depth = depth
        for child in self.children:
            child.set_depth(depth + 1)

    def print_tree(self, level: int = 0):
        """Print the tree structure starting from the current node."""
        print("  " * level + f"Node: {self.name}")
        for child in self.children:
            child.print_tree(level + 1)



    # ********************************
    # �R�R�ő������Z�b�g@240417
    # ********************************
    def set_attributes(self, row):

        #print("set_attributes(self, row):", row)
        # self.lot_size = int(row[3])
        # self.leadtime = int(row[4])  # �O��:SS=0
        # self.long_vacation_weeks = eval(row[5])

        self.lot_size = int(row["lot_size"])

        # ********************************
        # with using NetworkX
        # ********************************

        # weight��capacity�́Aedge=(node_A,node_B)�̑�����node�ň�ӂł͂Ȃ�

        self.leadtime = int(row["leadtime"])  # �O��:SS=0 # "weight"4NetworkX
        self.capacity = int(row["process_capa"])  # "capacity"4NetworkX

        self.long_vacation_weeks = eval(row["long_vacation_weeks"])

        # **************************
        # BU_SC_node_profile     business_unit_supplychain_node
        # **************************

        # @240421 �@�B�w�K�̃t���O��stop
        ## **************************
        ## plan_basic_parameter ***sequencing is TEMPORARY
        ## **************************
        #        self.PlanningYear           = row['plan_year']
        #        self.plan_engine            = row['plan_engine']
        #        self.reward_sw              = row['reward_sw']

        # ���i�KPSI�̃t���O��stop
        ## ***************************
        ## business unit identify
        ## ***************************
        #        self.product_name           = row['product_name']
        #        self.SC_tree_id             = row['SC_tree_id']
        #        self.node_from              = row['node_from']
        #        self.node_to                = row['node_to']


        # ***************************
        # �R�R����cost-profit evaluation �p�̑����Z�b�g
        # ***************************
        self.LT_boat = float(row["LT_boat"])



        self.SS_days = float(row["SS_days"])


        print("row[ customs_tariff_rate ]", row["customs_tariff_rate"])



        self.HS_code              = str(row["HS_code"])
        self.customs_tariff_rate  = float(row["customs_tariff_rate"])
        self.price_elasticity     = float(row["price_elasticity"])



        self.cost_standard_flag   = float(row["cost_standard_flag"])
        self.PSI_graph_flag       = str(row["PSI_graph_flag"])
        self.buffering_stock_flag = str(row["buffering_stock_flag"])

        self.base_leaf = None




    def set_parent(self):
        # def set_parent(self, node):

        # tree��H��Ȃ���e�m�[�h��T��
        if self.children == []:
            pass
        else:
            for child in self.children:
                child.parent = self
                # child.parent = node




    def set_cost_attr(
        self,
        price_sales_shipped,
        cost_total,
        profit,
        marketing_promotion=None,
        sales_admin_cost=None,
        SGA_total=None,
        custom_tax=None,
        tax_portion=None,
        logistics_costs=None,
        warehouse_cost=None,
        direct_materials_costs=None,
        purchase_total_cost=None,
        prod_indirect_labor=None,
        prod_indirect_others=None,
        direct_labor_costs=None,
        depreciation_others=None,
        manufacturing_overhead=None,
    ):

        # self.node_name = node_name # node_name is STOP
        self.price_sales_shipped = price_sales_shipped
        self.cost_total = cost_total
        self.profit = profit
        self.marketing_promotion = marketing_promotion
        self.sales_admin_cost = sales_admin_cost
        self.SGA_total = SGA_total
        self.custom_tax = custom_tax
        self.tax_portion = tax_portion
        self.logistics_costs = logistics_costs
        self.warehouse_cost = warehouse_cost
        self.direct_materials_costs = direct_materials_costs
        self.purchase_total_cost = purchase_total_cost
        self.prod_indirect_labor = prod_indirect_labor
        self.prod_indirect_others = prod_indirect_others
        self.direct_labor_costs = direct_labor_costs
        self.depreciation_others = depreciation_others
        self.manufacturing_overhead = manufacturing_overhead

    def print_cost_attr(self):

        # self.node_name = node_name # node_name is STOP
        print("self.price_sales_shipped", self.price_sales_shipped)
        print("self.cost_total", self.cost_total)
        print("self.profit", self.profit)
        print("self.marketing_promotion", self.marketing_promotion)
        print("self.sales_admin_cost", self.sales_admin_cost)
        print("self.SGA_total", self.SGA_total)
        print("self.custom_tax", self.custom_tax)
        print("self.tax_portion", self.tax_portion)
        print("self.logistics_costs", self.logistics_costs)
        print("self.warehouse_cost", self.warehouse_cost)
        print("self.direct_materials_costs", self.direct_materials_costs)
        print("self.purchase_total_cost", self.purchase_total_cost)
        print("self.prod_indirect_labor", self.prod_indirect_labor)
        print("self.prod_indirect_others", self.prod_indirect_others)
        print("self.direct_labor_costs", self.direct_labor_costs)
        print("self.depreciation_others", self.depreciation_others)
        print("self.manufacturing_overhead", self.manufacturing_overhead)





    def set_plan_range_lot_counts(self, plan_range, plan_year_st):

        # print("node.plan_range", self.name, self.plan_range)

        self.plan_range = plan_range
        self.plan_year_st = plan_year_st

        self.lot_counts = [0 for x in range(0, 53 * self.plan_range)]


        for child in self.children:

            child.set_plan_range_lot_counts(plan_range, plan_year_st)






# ****************************
# tree positioing
# ****************************
def set_positions_recursive(node, width_tracker):
    for child in node.children:
        child.depth = node.depth + 1
        child.width = width_tracker[child.depth]
        width_tracker[child.depth] += 1
        set_positions_recursive(child, width_tracker)

def adjust_positions(node):
    if not node.children:
        return node.width

    children_y_min = min(adjust_positions(child) for child in node.children)
    children_y_max = max(adjust_positions(child) for child in node.children)
    node.width = (children_y_min + children_y_max) / 2

    for i, child in enumerate(node.children):
        child.width += i * 0.1

    return node.width

def set_positions(root):
    width_tracker = [0] * 100
    set_positions_recursive(root, width_tracker)
    adjust_positions(root)




def set_node_costs(cost_table, nodes):
    """
    Set cost attributes for nodes based on the given cost table.

    Parameters:
        cost_table (pd.DataFrame): DataFrame containing cost data.
        nodes (dict): Dictionary of node instances.

    Returns:
        None
    """
    df_transposed = cost_table.transpose()

    rows = df_transposed.iterrows()
    next(rows)  # Skip the header row

    for index, row in rows:
        node_name = index
        try:
            node = nodes[node_name]
            node.set_cost_attr(*row)
            node.print_cost_attr()
        except KeyError:
            print(f"Warning: {node_name} not found in nodes. Continuing with next item.")




def set_parent_all(node):
    # preordering

    if node.children == []:
        pass
    else:
        node.set_parent()  # ���̒��Ŏqnode�����Đe��������B
        # def set_parent(self)

    for child in node.children:

        set_parent_all(child)




def print_parent_all(node):
    # preordering

    if node.children == []:
        pass
    else:
        print("node.parent and children", node.name, node.children)

    for child in node.children:

        print("child and parent", child.name, node.name)

        print_parent_all(child)





def build_tree_from_dict(tree_dict: Dict[str, List[str]]) -> Node:
    """
    Build a tree structure from a dictionary.

    Parameters:
        tree_dict (Dict[str, List[str]]): A dictionary where keys are parent node names
                                         and values are lists of child node names.

    Returns:
        Node: The root node of the constructed tree.
    """
    nodes: Dict[str, Node] = {}

    # Create all nodes
    for parent, children in tree_dict.items():
        if parent not in nodes:
            nodes[parent] = Node(parent)
        for child in children:
            if child not in nodes:
                nodes[child] = Node(child)

    # Link nodes
    for parent, children in tree_dict.items():
        for child in children:
            nodes[parent].add_child(nodes[child])

    # Assume the root is the one without a parent
    root_candidates = set(nodes.keys()) - {child for children in tree_dict.values() for child in children}
    if len(root_candidates) != 1:
        raise ValueError("Tree must have exactly one root")

    root_name = root_candidates.pop()
    root = nodes[root_name]
    root.set_depth(0)
    return root






def create_tree_set_attribute(file_name):
    """
    Create a supply chain tree and set attributes.

    Parameters:
        file_name (str): Path to the tree file.

    Returns:
        tuple[dict, str]: Dictionary of Node instances and the root node name.
    """
    width_tracker = defaultdict(int)
    root_node_name = ""

    # Read the tree file
    rows = read_tree_file(file_name)
    nodes = {row["child_node_name"]: Node(row["child_node_name"]) for row in rows}

    for row in rows:
        if row["Parent_node"] == "root":
            root_node_name = row["Child_node"]
            root = nodes[root_node_name]
            root.width += 4
        else:
            parent = nodes[row["Parent_node"]]
            child = nodes[row["Child_node"]]
            parent.add_child(child)
            child.set_attributes(row)

    return nodes, root_node_name




if __name__ == "__main__":

    # Example usage
    example_tree = {
        "root": ["child1", "child2"],
        "child1": ["child1_1", "child1_2"],
        "child2": ["child2_1"]
    }

    root_node = build_tree_from_dict(example_tree)
    root_node.print_tree()


