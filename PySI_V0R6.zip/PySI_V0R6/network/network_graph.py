#network_network_graph250114.py


#以下に、`network/network_graph.py` を生成します。
#このモジュールは、NetworkX を使用してネットワークグラフを作成・操作し、グラフの#描画や解析を行う機能を提供します。

#```python
# network/network_graph.py

import networkx as nx
import matplotlib.pyplot as plt

class NetworkGraph:
    def __init__(self):
        """Initialize a NetworkGraph instance with an empty directed graph."""
        self.graph = nx.DiGraph()

    def add_edge(self, parent, child, **attributes):
        """
        Add an edge to the graph with optional attributes.

        Parameters:
            parent (str): Name of the parent node.
            child (str): Name of the child node.
            attributes (dict): Additional attributes for the edge.
        """
        self.graph.add_edge(parent, child, **attributes)

    def add_node(self, node, **attributes):
        """
        Add a node to the graph with optional attributes.

        Parameters:
            node (str): Name of the node.
            attributes (dict): Additional attributes for the node.
        """
        self.graph.add_node(node, **attributes)

    def visualize_graph(self, title="Supply Chain Network", save_path=None):
        """
        Visualize the graph using Matplotlib.

        Parameters:
            title (str): Title for the graph visualization.
            save_path (str): File path to save the graph image (optional).
        """
        try:
            plt.figure(figsize=(12, 8))
            pos = nx.spring_layout(self.graph)  # Position nodes using spring layout
            nx.draw(
                self.graph, pos, with_labels=True, node_size=1500, node_color="skyblue", 
                font_size=10, font_weight="bold", edge_color="gray"
            )
            plt.title(title)
            if save_path:
                plt.savefig(save_path)
                print(f"Graph saved to {save_path}")
            else:
                plt.show()
        except Exception as e:
            print(f"Failed to visualize the graph: {e}")

    def get_shortest_path(self, source, target, weight=None):
        """
        Get the shortest path between two nodes.

        Parameters:
            source (str): Source node name.
            target (str): Target node name.
            weight (str): Edge attribute to use as weight (optional).

        Returns:
            list: List of nodes in the shortest path.
        """
        try:
            return nx.shortest_path(self.graph, source=source, target=target, weight=weight)
        except nx.NetworkXNoPath:
            print(f"No path exists between {source} and {target}")
            return None
        except Exception as e:
            print(f"Error finding shortest path: {e}")
            return None

    def analyze_graph(self):
        """
        Analyze the graph and return basic statistics.

        Returns:
            dict: Dictionary containing basic graph statistics.
        """
        try:
            stats = {
                "number_of_nodes": self.graph.number_of_nodes(),
                "number_of_edges": self.graph.number_of_edges(),
                "density": nx.density(self.graph),
                "is_directed": self.graph.is_directed(),
            }
            return stats
        except Exception as e:
            print(f"Failed to analyze the graph: {e}")
            return None
#```
#
#---
#
### 主な機能
#
#1. **グラフの構築**
#   - ノードやエッジを追加するためのメソッド `add_node` と `add_edge` を提供。
#
#2. **グラフの可視化**
#   - `visualize_graph` メソッドで NetworkX のグラフを Matplotlib を使用して描画#。
#
#3. **ショートパス探索**
#   - `get_shortest_path` で2つのノード間の最短経路を計算。
#
#4. **グラフの解析**
#   - `analyze_graph` メソッドでノード数、エッジ数、密度、グラフの有向性などの基#本統計情報を取得。
#
#---
#
#### 統合の次のステップ
#1. **このコードを `network` ディレクトリに保存**。
#2. 他のモジュール（例: GUI）から `NetworkGraph` を呼び出し、サプライチェーンの##可視化に使用。
##3. 必要に応じて、ショートパス解析やエッジ属性の操作を追加実装。
#
#続けて、ユーティリティやテストモジュールの作成も可能です！
#
#
#
#
#
#
#
#
#
